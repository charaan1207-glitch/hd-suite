@echo off
rem HD Suite - double-click to start (needs Java 8 or newer)
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
    echo Java is not installed on this computer.
    echo Download and install it from https://adoptium.net  ^(Temurin, JDK 17 or 21^), then run this again.
    pause
    exit /b 1
)

rem If the source code was changed and a compiler is available, rebuild first
where javac >nul 2>nul
if not errorlevel 1 (
    if not exist out mkdir out
    javac -encoding UTF-8 -d out src\*.java
    if errorlevel 1 (
        echo.
        echo Compilation failed - see the errors above.
        pause
        exit /b 1
    )
    java -cp out MainApp
    exit /b
)

rem No compiler (only a Java runtime): run the ready-made jar
java -jar HDSuite.jar
