# HD Suite - Java Swing Mini Project

**Team:** Hemashree TN (25BBTCS093) & Divya Reddy GN (25BBTCS067)

Two GUI applications behind one home screen:

| Module | What it does |
|---|---|
| **HD Rail** - Railway Reservation Form | Pick stations, train, class and date; check the fare breakup; book a ticket (PNR, berth, waiting list); cancel by PNR with refund |
| **HD Cart** - Online Shopping Cart Simulation | Browse 13 products with pictures, ratings and prices; filter, search and sort; add to cart with quantity steppers; coupons, gift wrap, payment mode; checkout with payment simulation and receipt |

## How to run

1. Install Java (version 8 or newer, e.g. Temurin JDK 17 from adoptium.net). Check it with `java -version`.
2. Double-click **`run.bat`** or **`HDSuite.jar`**, or run `java -jar HDSuite.jar`. See `HOW-TO-RUN.txt` for every option.
3. To compile from source yourself:

```
javac -encoding UTF-8 -d out src\*.java
java -cp out MainApp
```

## How the syllabus requirements are met

| Requirement | Where |
|---|---|
| Swing components | `JLabel`, `JTextField`, `JTextArea`, `JButton`, `JComboBox`, `JRadioButton`, `JCheckBox`, `JToggleButton`, `JMenuBar`/`JMenu`/`JMenuItem`, `JTable`, `JProgressBar`, `JOptionPane` dialogs |
| Layout managers | `BorderLayout` (every window), `GridLayout` (forms, product grid), `FlowLayout` (button rows), `BoxLayout` (cart sidebar), `CardLayout` (checkout steps), `GridBagLayout` (payment screen) |
| Classes + encapsulation | Every model class keeps fields `private` with getters: `Train`, `Passenger`, `Ticket`, `Product`, `CartItem`, `ShoppingCart`, `Store` |
| Inheritance | `Ticket` -> `SleeperTicket`, `AcThreeTierTicket`, `AcTwoTierTicket`; `Product` -> `Electronics`, `Clothing`, `Book`, `Grocery`; `Coupon` -> `PercentCoupon`, `FlatCoupon`; `FlatButton extends JButton` |
| Polymorphism | `Ticket.getTotalFare()` calls overridden `getRatePerKm()`, `getGstPercent()`, `getBerthType()`; `CartItem.getTax()` calls overridden `getTaxPercent()`; `Coupon.discountOn()` |
| Delegation event model | Frames implement `ActionListener` and `ItemListener`; adapter classes `WindowAdapter` (exit confirm), `MouseAdapter` (hover, double-click, picture click), `KeyAdapter` (digits only, live search), `FocusAdapter` (date field); `javax.swing.Timer` (clock, toast, payment) |
| Validation + exceptions | Custom checked `ValidationException`; `Validator` class catches `NumberFormatException` and `DateTimeParseException`; errors shown in dialogs or inline in red |

## Source files (`src/`)

- **Common:** `MainApp` (entry point, home screen), `UiUtil`, `Art` (all pictures drawn in Java 2D, no image files), `FlatButton`, `Validator`, `ValidationException`, `Money`
- **HD Rail:** `RailwayReservationFrame`, `JourneyPanel`, `ReservationSystem`, `Train`, `Passenger`, `Ticket`, `SleeperTicket`, `AcThreeTierTicket`, `AcTwoTierTicket`
- **HD Cart:** `ShoppingCartFrame`, `ProductCard`, `CartRow`, `CheckoutDialog`, `Store`, `ShoppingCart`, `CartItem`, `Coupon`, `Product`, `Electronics`, `Clothing`, `Book`, `Grocery`

All trains, prices, ratings and tax rates are demo data.

`screenshots/` holds every screen of a full test run, ready for the presentation.
