import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;

/** Colours, fonts and small GUI helpers shared by every window. */
public final class UiUtil {

    public static final Color HOME_COLOR = new Color(38, 50, 56);
    public static final Color RAIL_COLOR = new Color(21, 101, 192);
    public static final Color SHOP_COLOR = new Color(216, 92, 22);
    public static final Color PAGE_BG = new Color(243, 245, 249);
    public static final Color OK_GREEN = new Color(46, 125, 50);
    public static final Color WARN_ORANGE = new Color(230, 100, 0);
    public static final Color ERROR_RED = new Color(198, 40, 40);

    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BASE_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font BOLD_FONT = new Font("Segoe UI", Font.BOLD, 13);

    private UiUtil() {
    }

    /** Native Windows/Mac look plus one consistent font for all components. */
    public static void useSystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // The default Java look and feel is fine as a fallback.
        }
        FontUIResource font = new FontUIResource(BASE_FONT);
        String[] keys = {"Label.font", "TextField.font", "ComboBox.font", "RadioButton.font", "CheckBox.font",
            "Button.font", "Table.font", "TableHeader.font", "Menu.font", "MenuItem.font", "MenuBar.font",
            "TitledBorder.font", "OptionPane.messageFont", "OptionPane.buttonFont", "List.font", "ToolTip.font"};
        for (String key : keys) {
            UIManager.put(key, font);
        }
    }

    /** Consolas if installed, otherwise the standard monospaced font. */
    public static Font monoFont(int size) {
        for (String family : GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
            if (family.equals("Consolas")) {
                return new Font("Consolas", Font.PLAIN, size);
            }
        }
        return new Font(Font.MONOSPACED, Font.PLAIN, size);
    }

    /** Gradient banner with a picture on the left. */
    public static JPanel header(String title, String subtitle, Color color, javax.swing.Icon icon) {
        JPanel panel = header(title, subtitle, color);
        JLabel picture = new JLabel(icon);
        picture.setBorder(new EmptyBorder(0, 0, 0, 16));
        JPanel text = new JPanel(new BorderLayout(0, 2));
        text.setOpaque(false);
        for (java.awt.Component c : panel.getComponents()) {
            Object where = ((BorderLayout) panel.getLayout()).getConstraints(c);
            text.add(c, where);
        }
        panel.removeAll();
        panel.add(picture, BorderLayout.WEST);
        panel.add(text, BorderLayout.CENTER);
        return panel;
    }

    /** Gradient banner shown at the top of every window. */
    public static JPanel header(String title, String subtitle, final Color color) {
        JPanel panel = new JPanel(new BorderLayout(0, 2)) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, color, getWidth(), 0, color.darker().darker()));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        panel.setBorder(new EmptyBorder(12, 20, 12, 20));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(Color.WHITE);
        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(SUBTITLE_FONT);
        subtitleLabel.setForeground(new Color(230, 236, 245));
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(subtitleLabel, BorderLayout.SOUTH);
        return panel;
    }

    /** Titled, padded border for a section of a window. */
    public static Border section(String title) {
        TitledBorder titled = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(200, 206, 216)), title,
                TitledBorder.LEFT, TitledBorder.TOP, BOLD_FONT, new Color(55, 65, 81));
        return BorderFactory.createCompoundBorder(titled, new EmptyBorder(4, 8, 8, 8));
    }

    /** KeyAdapter that lets the user type only digits, up to maxLength characters. */
    public static void allowDigitsOnly(final JTextField field, final int maxLength) {
        field.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (Character.isISOControl(c)) {
                    return; // backspace, delete, enter
                }
                boolean full = field.getText().length() >= maxLength && field.getSelectedText() == null;
                if (!Character.isDigit(c) || full) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    /** Uses the wanted size, but never bigger than the screen (e.g. 1366 x 768 laptops). */
    public static void fitToScreen(java.awt.Window window, int width, int height) {
        java.awt.Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        window.setSize(Math.min(width, screen.width), Math.min(height, screen.height));
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(24);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setFont(BOLD_FONT);
        table.setGridColor(new Color(225, 228, 234));
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check your input", JOptionPane.ERROR_MESSAGE);
    }

    public static void showInfo(Component parent, String title, String message) {
        JOptionPane.showMessageDialog(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
}
