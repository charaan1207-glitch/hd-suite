import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 * HD Suite - home screen and program entry point.
 * Opens the Railway Reservation and Online Shopping Cart modules.
 */
public class MainApp extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    /** Shown on the home screen - put your team members' names here. */
    public static final String TEAM = "Team: Hemashree TN (25BBTCS093)  &  Divya Reddy GN (25BBTCS067)";

    private static final DateTimeFormatter CLOCK_FORMAT = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy   hh:mm:ss a", java.util.Locale.ENGLISH);

    // One shared copy of the data, so bookings and the cart survive closing and reopening a module window.
    private final ReservationSystem reservationSystem = new ReservationSystem();
    private final Store store = new Store();
    private final ShoppingCart cart = new ShoppingCart();
    private RailwayReservationFrame railwayFrame;
    private ShoppingCartFrame shopFrame;

    private final JButton railwayButton = new FlatButton("Open Railway Reservation", UiUtil.RAIL_COLOR);
    private final JButton shopButton = new FlatButton("Open Shopping Cart", UiUtil.SHOP_COLOR);
    private final JMenuItem railwayItem = new JMenuItem("Railway Reservation");
    private final JMenuItem shopItem = new JMenuItem("Online Shopping Cart");
    private final JMenuItem exitItem = new JMenuItem("Exit");
    private final JMenuItem aboutItem = new JMenuItem("About");
    private final JLabel clockLabel = new JLabel();
    private final JLabel statsLabel = new JLabel();

    public MainApp() {
        super("HD Suite");
        setJMenuBar(buildMenuBar());

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiUtil.PAGE_BG);
        root.add(UiUtil.header("HD Suite  -  Java Swing Mini Project", TEAM, UiUtil.HOME_COLOR),
                BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(1, 2, 20, 0));
        cards.setOpaque(false);
        cards.setBorder(new EmptyBorder(24, 24, 16, 24));
        cards.add(moduleCard("HD Rail", "Railway Reservation Form", UiUtil.RAIL_COLOR, Art.train(110, 80, UiUtil.RAIL_COLOR),
            new String[] {
                "Search trains between 6 cities",
                "Fare breakup with concessions and GST",
                "Berth allotment and waiting list",
                "Cancel by PNR with refund"}, railwayButton));
        cards.add(moduleCard("HD Cart", "Online Shopping Cart Simulation", UiUtil.SHOP_COLOR, Art.cart(80, UiUtil.SHOP_COLOR),
            new String[] {
                "Shop 13 products with pictures and ratings",
                "Category-wise tax, coupons and delivery",
                "Live cart with quantity steppers",
                "Checkout, payment and order receipt"}, shopButton));
        root.add(cards, BorderLayout.CENTER);

        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(225, 229, 236));
        statusBar.setBorder(new EmptyBorder(6, 14, 6, 14));
        statusBar.add(statsLabel, BorderLayout.WEST);
        statusBar.add(clockLabel, BorderLayout.EAST);
        root.add(statusBar, BorderLayout.SOUTH);
        setContentPane(root);

        railwayButton.setName("openRailway");
        shopButton.setName("openShop");
        for (javax.swing.AbstractButton source : new javax.swing.AbstractButton[] {
            railwayButton, shopButton, railwayItem, shopItem, exitItem, aboutItem}) {
            source.addActionListener(this);
        }

        // WindowAdapter: ask before closing the whole application
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                confirmExit();
            }
        });

        // Swing Timer: live clock and session counters, updated every second
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateStatusBar();
            }
        });
        timer.start();
        updateStatusBar();

        setSize(940, 560);
        setMinimumSize(new Dimension(860, 520));
        setLocationRelativeTo(null);
    }

    private JMenuBar buildMenuBar() {
        JMenu modules = new JMenu("Modules");
        modules.setMnemonic(KeyEvent.VK_M);
        modules.add(railwayItem);
        modules.add(shopItem);
        modules.addSeparator();
        modules.add(exitItem);
        JMenu help = new JMenu("Help");
        help.setMnemonic(KeyEvent.VK_H);
        help.add(aboutItem);
        JMenuBar bar = new JMenuBar();
        bar.add(modules);
        bar.add(help);
        return bar;
    }

    /** A clickable card for one module; MouseAdapter highlights it on hover. */
    private JPanel moduleCard(String title, String subtitle, final Color color, javax.swing.Icon picture, String[] features,
                              final JButton openButton) {
        final JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setBackground(Color.WHITE);
        final Border normal = BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(6, 1, 1, 1, color), new EmptyBorder(16, 18, 16, 18));
        final Border hover = BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(6, 3, 3, 3, color), new EmptyBorder(14, 16, 14, 16));
        card.setBorder(normal);

        JLabel titleLabel = new JLabel("<html><span style='font-size:22px'><b>" + title + "</b></span><br>"
                + "<span style='font-size:12px;color:#5a626e'>" + subtitle + "</span></html>", picture, JLabel.LEFT);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        titleLabel.setForeground(color);
        titleLabel.setIconTextGap(14);
        card.add(titleLabel, BorderLayout.NORTH);

        StringBuilder html = new StringBuilder("<html><div style='font-size:12px'>");
        for (String feature : features) {
            html.append("<font color='").append(String.format("#%06x", color.getRGB() & 0xFFFFFF))
                    .append("'><b>&bull;</b></font>&nbsp; ").append(feature).append("<br>");
        }
        html.append("</div></html>");
        JLabel list = new JLabel(html.toString());
        list.setVerticalAlignment(JLabel.TOP);
        card.add(list, BorderLayout.CENTER);

        openButton.setFont(UiUtil.BOLD_FONT);
        openButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.add(openButton, BorderLayout.SOUTH);

        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBorder(hover);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBorder(normal);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                openButton.doClick();
            }
        });
        return card;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == railwayButton || source == railwayItem) {
            openRailway();
        } else if (source == shopButton || source == shopItem) {
            openShop();
        } else if (source == exitItem) {
            confirmExit();
        } else if (source == aboutItem) {
            UiUtil.showInfo(this, "About HD Suite", "HD Suite\nJava Swing / AWT mini project\n\n"
                    + "Module 1: Railway Reservation Form (demo)\nModule 2: Online Shopping Cart Simulation\n\n"
                    + TEAM);
        }
    }

    private void openRailway() {
        if (railwayFrame == null || !railwayFrame.isDisplayable()) {
            railwayFrame = new RailwayReservationFrame(reservationSystem);
        }
        railwayFrame.setVisible(true);
        railwayFrame.toFront();
    }

    private void openShop() {
        if (shopFrame == null || !shopFrame.isDisplayable()) {
            shopFrame = new ShoppingCartFrame(store, cart);
        }
        shopFrame.setVisible(true);
        shopFrame.toFront();
    }

    private void updateStatusBar() {
        clockLabel.setText(LocalDateTime.now().format(CLOCK_FORMAT));
        statsLabel.setText("Tickets booked: " + reservationSystem.getBookings().size()
                + "     Orders placed: " + store.getOrdersPlaced()
                + "     Items in cart: " + cart.getTotalQuantity());
    }

    private void confirmExit() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Exit HD Suite?\nBookings and orders made in this session will be lost.",
                "Exit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                UiUtil.useSystemLookAndFeel();
                new MainApp().setVisible(true);
            }
        });
    }
}
