import java.time.LocalDate;

/** AC 3 Tier (3A): same berth layout as Sleeper, higher fare plus 5% GST. */
public class AcThreeTierTicket extends Ticket {

    public static final int SEATS = 6;

    public AcThreeTierTicket(String pnr, Passenger passenger, Train train, LocalDate journeyDate,
                             String berthPreference, boolean meals, boolean insurance) {
        super(pnr, passenger, train, journeyDate, berthPreference, meals, insurance);
    }

    @Override
    public String getClassCode() {
        return "3A";
    }

    @Override
    public String getClassName() {
        return "AC 3 Tier";
    }

    @Override
    public int getTotalSeats() {
        return SEATS;
    }

    @Override
    protected double getRatePerKm() {
        return 1.50;
    }

    @Override
    protected double getReservationCharge() {
        return 40.0;
    }

    @Override
    protected double getGstPercent() {
        return 5.0;
    }

    @Override
    protected String getCoachCode() {
        return "B1";
    }

    @Override
    public double getCancellationCharge() {
        return 180.0;
    }
}
