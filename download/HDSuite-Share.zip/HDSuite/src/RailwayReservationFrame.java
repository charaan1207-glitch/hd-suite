import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Railway Reservation window.
 *
 * Event handling uses the delegation event model:
 *   - this class is the ActionListener for buttons, menu items and the date field,
 *   - this class is the ItemListener for the station / train / class combo boxes,
 *   - adapter classes handle focus (FocusAdapter), double-clicks (MouseAdapter)
 *     and digit-only typing (KeyAdapter, in UiUtil).
 */
public class RailwayReservationFrame extends JFrame implements ActionListener, ItemListener {

    private static final long serialVersionUID = 1L;

    private static final String[] CLASS_OPTIONS = {"SL - Sleeper", "3A - AC 3 Tier", "2A - AC 2 Tier"};
    private static final String[] BERTH_OPTIONS =
        {"No Preference", "Lower", "Middle", "Upper", "Side Lower", "Side Upper"};
    private static final String[] TABLE_COLUMNS =
        {"PNR", "Passenger", "Age", "Train", "Class", "Journey Date", "Status", "Fare (Rs)"};

    private final ReservationSystem system;

    // ----- form -----
    private final JTextField nameField = new JTextField();
    private final JTextField ageField = new JTextField();
    private final JRadioButton maleRadio = new JRadioButton("Male");
    private final JRadioButton femaleRadio = new JRadioButton("Female");
    private final JRadioButton otherRadio = new JRadioButton("Other");
    private final ButtonGroup genderGroup = new ButtonGroup();
    private final JTextField mobileField = new JTextField();
    private final JComboBox<String> fromCombo;
    private final JComboBox<String> toCombo;
    private final JComboBox<Train> trainCombo = new JComboBox<Train>();
    private final JComboBox<String> classCombo = new JComboBox<String>(CLASS_OPTIONS);
    private final JTextField dateField = new JTextField();
    private final JComboBox<String> berthCombo = new JComboBox<String>(BERTH_OPTIONS);
    private final JCheckBox mealsBox = new JCheckBox("Meals");
    private final JCheckBox insuranceBox = new JCheckBox("Insurance (Rs 10)");
    private final JLabel availabilityLabel = new JLabel(" ");

    // ----- buttons and menu -----
    private final JButton fareButton = new FlatButton("Check Fare", Color.WHITE, UiUtil.RAIL_COLOR);
    private final JButton bookButton = new FlatButton("Book Ticket", UiUtil.RAIL_COLOR);
    private final JButton cancelButton = new FlatButton("Cancel Ticket", Color.WHITE, UiUtil.ERROR_RED);
    private final JButton clearButton = new FlatButton("Clear Form", Color.WHITE, new Color(55, 65, 81));
    private final JourneyPanel journeyPanel = new JourneyPanel();
    private final JMenuItem newItem = new JMenuItem("New Booking");
    private final JMenuItem cancelItem = new JMenuItem("Cancel Ticket...");
    private final JMenuItem closeItem = new JMenuItem("Close Window");
    private final JMenuItem rulesItem = new JMenuItem("Fare Rules");
    private final JMenuItem aboutItem = new JMenuItem("About");

    // ----- output -----
    private final JTextArea ticketArea = new JTextArea();
    private final DefaultTableModel tableModel = new DefaultTableModel(TABLE_COLUMNS, 0) {
        private static final long serialVersionUID = 1L;

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable bookingTable = new JTable(tableModel);
    private final JLabel statusBar = new JLabel(" Ready");

    public RailwayReservationFrame(ReservationSystem system) {
        super("HD Rail - Railway Reservation System");
        this.system = system;
        String[] stations = system.getStations();
        fromCombo = new JComboBox<String>(stations);
        toCombo = new JComboBox<String>(stations);
        fromCombo.setSelectedItem("Chennai Central");
        toCombo.setSelectedItem("KSR Bengaluru");

        setJMenuBar(buildMenuBar());
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiUtil.PAGE_BG);
        root.add(UiUtil.header("Railway Reservation System",
                "Search trains  >  check fare  >  book  >  cancel with refund      (demo timetable)",
                UiUtil.RAIL_COLOR, Art.train(64, 46, Color.WHITE)), BorderLayout.NORTH);
        root.add(buildCenter(), BorderLayout.CENTER);
        statusBar.setBorder(new EmptyBorder(4, 12, 4, 12));
        root.add(statusBar, BorderLayout.SOUTH);
        setContentPane(root);

        nameComponents();
        registerListeners();
        refreshTrains();
        clearForm();
        refreshTable();

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        UiUtil.fitToScreen(this, 1220, 820);
        setMinimumSize(new Dimension(1000, 640));
        setLocationRelativeTo(null);
    }

    // =====================================================================
    //  Layout
    // =====================================================================

    private JMenuBar buildMenuBar() {
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        newItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
        cancelItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_DOWN_MASK));
        closeItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_DOWN_MASK));
        fileMenu.add(newItem);
        fileMenu.add(cancelItem);
        fileMenu.addSeparator();
        fileMenu.add(closeItem);

        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        helpMenu.add(rulesItem);
        helpMenu.add(aboutItem);

        JMenuBar bar = new JMenuBar();
        bar.add(fileMenu);
        bar.add(helpMenu);
        return bar;
    }

    private JPanel buildCenter() {
        JPanel top = new JPanel(new GridLayout(1, 2, 12, 0));
        top.setOpaque(false);
        top.add(buildFormPanel());
        top.add(buildTicketPanel());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 4));
        buttons.setOpaque(false);
        bookButton.setPreferredSize(new Dimension(170, 38));
        fareButton.setToolTipText("Show the fare breakup without booking");
        bookButton.setToolTipText("Book the ticket and generate a PNR");
        cancelButton.setToolTipText("Cancel a booking by PNR and see the refund");
        clearButton.setToolTipText("Reset the form for a new passenger");
        buttons.add(fareButton);
        buttons.add(bookButton);
        buttons.add(cancelButton);
        buttons.add(clearButton);

        JPanel upper = new JPanel(new BorderLayout(0, 6));
        upper.setOpaque(false);
        upper.add(top, BorderLayout.CENTER);
        upper.add(buttons, BorderLayout.SOUTH);

        JPanel center = new JPanel(new BorderLayout(0, 8));
        center.setOpaque(false);
        center.setBorder(new EmptyBorder(10, 12, 4, 12));
        center.add(upper, BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        return center;
    }

    private JPanel buildFormPanel() {
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        genderPanel.setOpaque(false);
        for (JRadioButton radio : new JRadioButton[] {maleRadio, femaleRadio, otherRadio}) {
            radio.setOpaque(false);
            genderGroup.add(radio);
            genderPanel.add(radio);
        }

        JPanel extrasPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        extrasPanel.setOpaque(false);
        mealsBox.setOpaque(false);
        insuranceBox.setOpaque(false);
        extrasPanel.add(mealsBox);
        extrasPanel.add(insuranceBox);

        availabilityLabel.setFont(UiUtil.BOLD_FONT);

        JPanel form = new JPanel(new GridLayout(0, 2, 10, 4));
        form.setBackground(Color.WHITE);
        form.setBorder(UiUtil.section("Passenger & Journey Details"));
        addRow(form, "Passenger name", nameField);
        addRow(form, "Age (years)", ageField);
        addRow(form, "Gender", genderPanel);
        addRow(form, "Mobile number", mobileField);
        addRow(form, "From station", fromCombo);
        addRow(form, "To station", toCombo);
        addRow(form, "Train", trainCombo);
        addRow(form, "Travel class", classCombo);
        addRow(form, "Journey date (dd-MM-yyyy)", dateField);
        addRow(form, "Berth preference", berthCombo);
        addRow(form, "Add-ons", extrasPanel);
        addRow(form, "Seat availability", availabilityLabel);
        return form;
    }

    private static void addRow(JPanel form, String label, Component field) {
        form.add(new JLabel(label));
        form.add(field);
    }

    private JPanel buildTicketPanel() {
        ticketArea.setEditable(false);
        ticketArea.setFont(UiUtil.monoFont(13));
        ticketArea.setMargin(new java.awt.Insets(6, 8, 6, 8));
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(Color.WHITE);
        panel.setBorder(UiUtil.section("Your Journey & Ticket"));
        panel.add(journeyPanel, BorderLayout.NORTH);
        JScrollPane ticketScroll = new JScrollPane(ticketArea);
        ticketScroll.setPreferredSize(new Dimension(400, 250)); // scrolls, so the bookings table keeps its room
        panel.add(ticketScroll, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildTablePanel() {
        UiUtil.styleTable(bookingTable);
        bookingTable.getColumnModel().getColumn(6).setCellRenderer(new StatusRenderer());
        bookingTable.getColumnModel().getColumn(3).setPreferredWidth(200);
        JScrollPane scroll = new JScrollPane(bookingTable);
        scroll.setPreferredSize(new Dimension(100, 150));
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(UiUtil.section("My Bookings   (double-click a row to view its ticket)"));
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    /** Names let automated tests find components; they are not visible to the user. */
    private void nameComponents() {
        JComponent[] components = {nameField, ageField, maleRadio, femaleRadio, otherRadio, mobileField, fromCombo,
            toCombo, trainCombo, classCombo, dateField, berthCombo, mealsBox, insuranceBox, availabilityLabel,
            fareButton, bookButton, cancelButton, clearButton, ticketArea, bookingTable};
        String[] names = {"name", "age", "male", "female", "other", "mobile", "from", "to", "train", "class",
            "date", "berth", "meals", "insurance", "availability", "fare", "book", "cancel", "clear", "ticket",
            "bookings"};
        for (int i = 0; i < components.length; i++) {
            components[i].setName(names[i]);
        }
    }

    // =====================================================================
    //  Event handling
    // =====================================================================

    private void registerListeners() {
        AbstractButton[] actionSources = {fareButton, bookButton, cancelButton, clearButton,
            newItem, cancelItem, closeItem, rulesItem, aboutItem};
        for (AbstractButton source : actionSources) {
            source.addActionListener(this);
        }
        dateField.addActionListener(this);

        fromCombo.addItemListener(this);
        toCombo.addItemListener(this);
        trainCombo.addItemListener(this);
        classCombo.addItemListener(this);

        // FocusAdapter: re-check seats when the user leaves the date field
        dateField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                refreshAvailability();
            }
        });

        // MouseAdapter: double-click a booking to see its ticket
        bookingTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    showSelectedBooking();
                }
            }
        });

        // KeyAdapter: digits only
        UiUtil.allowDigitsOnly(ageField, 3);
        UiUtil.allowDigitsOnly(mobileField, 10);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == fareButton) {
            checkFare();
        } else if (source == bookButton) {
            bookTicket();
        } else if (source == cancelButton || source == cancelItem) {
            cancelTicket();
        } else if (source == clearButton || source == newItem) {
            clearForm();
        } else if (source == dateField) {
            refreshAvailability();
        } else if (source == rulesItem) {
            showFareRules();
        } else if (source == aboutItem) {
            showAbout();
        } else if (source == closeItem) {
            dispose();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() != ItemEvent.SELECTED) {
            return;
        }
        if (e.getSource() == fromCombo || e.getSource() == toCombo) {
            refreshTrains();
        } else {
            refreshAvailability();
        }
    }

    // =====================================================================
    //  Actions
    // =====================================================================

    /** Everything the user typed, already validated. */
    private static final class BookingInput {
        private Passenger passenger;
        private Train train;
        private String classCode;
        private LocalDate date;
        private String berth;
        private boolean meals;
        private boolean insurance;
    }

    private BookingInput readForm() throws ValidationException {
        BookingInput in = new BookingInput();
        String name = Validator.requireName(nameField.getText(), "Passenger name");
        int age = Validator.parseIntInRange(ageField.getText(), "Age", 1, 120);
        if (age < 5) {
            throw new ValidationException("Children below 5 years travel free and do not need a reserved berth.");
        }
        String gender = selectedGender();
        if (gender == null) {
            throw new ValidationException("Please select the passenger's gender.");
        }
        String mobile = Validator.requireMobile(mobileField.getText());

        String from = (String) fromCombo.getSelectedItem();
        String to = (String) toCombo.getSelectedItem();
        if (from == null || from.equals(to)) {
            throw new ValidationException("From and To stations cannot be the same.");
        }
        in.train = (Train) trainCombo.getSelectedItem();
        if (in.train == null) {
            throw new ValidationException("No direct train runs from " + from + " to " + to
                    + ". Please choose another route.");
        }
        in.date = Validator.parseFutureDate(dateField.getText(), "Journey date", LocalDate.now(),
                ReservationSystem.ADVANCE_BOOKING_DAYS);

        in.passenger = new Passenger(name, age, gender, mobile);
        in.classCode = selectedClassCode();
        in.berth = (String) berthCombo.getSelectedItem();
        in.meals = mealsBox.isSelected();
        in.insurance = insuranceBox.isSelected();
        return in;
    }

    private void checkFare() {
        try {
            BookingInput in = readForm();
            Ticket quote = system.quote(in.classCode, in.passenger, in.train, in.date, in.berth, in.meals, in.insurance);
            showTicket(quote);
            setStatus("Fare for " + in.passenger.getName() + ": " + Money.format(quote.getTotalFare())
                    + "  -  click Book Ticket to confirm.");
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void bookTicket() {
        try {
            BookingInput in = readForm();
            Ticket quote = system.quote(in.classCode, in.passenger, in.train, in.date, in.berth, in.meals, in.insurance);
            int choice = JOptionPane.showConfirmDialog(this,
                    "Book " + quote.getClassName() + " on " + in.train.getNumber() + " " + in.train.getName()
                    + "\nfor " + in.passenger.getName() + " on " + in.date.format(Validator.DATE_FORMAT)
                    + "?\n\nTotal fare: " + Money.format(quote.getTotalFare()),
                    "Confirm Booking", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) {
                setStatus("Booking not made.");
                return;
            }
            Ticket ticket = system.book(in.classCode, in.passenger, in.train, in.date, in.berth, in.meals, in.insurance);
            showTicket(ticket);
            refreshTable();
            refreshAvailability();
            String note = ticket.getStatus() == Ticket.Status.WAITING
                    ? "\n\nThe class is full, so this ticket is on the waiting list."
                    + "\nIt will be confirmed automatically if someone cancels."
                    : "";
            UiUtil.showInfo(this, "Booking Successful",
                    "PNR: " + ticket.getPnr() + "\nStatus: " + ticket.getStatusText()
                    + "\nFare paid: " + Money.format(ticket.getTotalFare()) + note);
            setStatus("Booked PNR " + ticket.getPnr() + " (" + ticket.getStatusText()
                    + ")  -  enter the next passenger, the journey details are kept.");
            clearPassengerFields();
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    /** After a booking: empty the passenger details but keep the route, train, class and date. */
    private void clearPassengerFields() {
        nameField.setText("");
        ageField.setText("");
        mobileField.setText("");
        genderGroup.clearSelection();
        berthCombo.setSelectedIndex(0);
        mealsBox.setSelected(false);
        insuranceBox.setSelected(false);
        nameField.requestFocusInWindow();
    }

    private void cancelTicket() {
        String suggested = "";
        int row = bookingTable.getSelectedRow();
        if (row >= 0) {
            suggested = String.valueOf(tableModel.getValueAt(row, 0));
        }
        String pnr = (String) JOptionPane.showInputDialog(this, "Enter the 10-digit PNR number to cancel:",
                "Cancel Ticket", JOptionPane.QUESTION_MESSAGE, null, null, suggested);
        if (pnr == null) {
            return; // user pressed Cancel
        }
        try {
            Ticket ticket = system.requireActiveTicket(pnr);
            double charge = ticket.getStatus() == Ticket.Status.CONFIRMED
                    ? ticket.getCancellationCharge() : ReservationSystem.WAITLIST_CANCELLATION_CHARGE;
            int choice = JOptionPane.showConfirmDialog(this,
                    "Cancel PNR " + ticket.getPnr() + " for " + ticket.getPassenger().getName()
                    + " (" + ticket.getStatusText() + ")?\n\nCancellation charge: " + Money.format(charge),
                    "Confirm Cancellation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) {
                return;
            }
            system.cancel(pnr);
            showTicket(ticket);
            refreshTable();
            refreshAvailability();
            UiUtil.showInfo(this, "Ticket Cancelled", "PNR " + ticket.getPnr() + " has been cancelled.\nRefund: "
                    + Money.format(ticket.getRefundAmount()));
            setStatus("Cancelled PNR " + ticket.getPnr() + ", refund " + Money.format(ticket.getRefundAmount()));
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void clearForm() {
        nameField.setText("");
        ageField.setText("");
        mobileField.setText("");
        genderGroup.clearSelection();
        classCombo.setSelectedIndex(0);
        berthCombo.setSelectedIndex(0);
        mealsBox.setSelected(false);
        insuranceBox.setSelected(false);
        dateField.setText(LocalDate.now().plusDays(1).format(Validator.DATE_FORMAT));
        ticketArea.setText(welcomeText());
        ticketArea.setCaretPosition(0);
        refreshAvailability();
        setStatus("Ready for a new booking.");
        nameField.requestFocusInWindow();
    }

    private void showSelectedBooking() {
        int row = bookingTable.getSelectedRow();
        if (row < 0) {
            return;
        }
        Ticket ticket = system.findByPnr(String.valueOf(tableModel.getValueAt(row, 0)));
        if (ticket != null) {
            showTicket(ticket);
            setStatus("Showing PNR " + ticket.getPnr());
        }
    }

    private void showFareRules() {
        Passenger adult = new Passenger("Sample", 30, "Male", "9000000000");
        Train train = system.findTrains("Chennai Central", "KSR Bengaluru").get(0);
        StringBuilder sb = new StringBuilder("Class          Rate/km  Reservation  GST   Cancel charge\n");
        for (String option : CLASS_OPTIONS) {
            Ticket t = system.quote(option.substring(0, 2), adult, train, LocalDate.now(), "No Preference",
                    false, false);
            sb.append(String.format(java.util.Locale.ENGLISH, "%-14s %7.2f  %11.2f  %3.0f%%  %13.2f\n",
                    t.getClassName(), t.getRatePerKm(), t.getReservationCharge(), t.getGstPercent(),
                    t.getCancellationCharge()));
        }
        sb.append("\nConcession on base fare:  senior citizen (60+) 40%,  child (5-11) 50%\n");
        sb.append("Waiting-list ticket cancellation charge: Rs 60\n");
        sb.append("Maximum waiting list per class: ").append(ReservationSystem.MAX_WAITING_LIST).append('\n');
        sb.append("Advance booking window: ").append(ReservationSystem.ADVANCE_BOOKING_DAYS).append(" days");
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(UiUtil.monoFont(13));
        JOptionPane.showMessageDialog(this, area, "Fare Rules", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAbout() {
        UiUtil.showInfo(this, "About", "HD Rail - Railway Reservation System\nPart of HD Suite - Java Swing mini project"
                + "\n\nTrains, timings and fares are demo data for learning purposes.");
    }

    // =====================================================================
    //  Helpers
    // =====================================================================

    private void refreshTrains() {
        String from = (String) fromCombo.getSelectedItem();
        String to = (String) toCombo.getSelectedItem();
        trainCombo.removeAllItems();
        if (from != null && !from.equals(to)) {
            for (Train train : system.findTrains(from, to)) {
                trainCombo.addItem(train);
            }
        }
        refreshAvailability();
    }

    private void refreshAvailability() {
        String from = (String) fromCombo.getSelectedItem();
        if (from != null && from.equals(toCombo.getSelectedItem())) {
            setAvailability("From and To are the same", UiUtil.ERROR_RED);
            journeyPanel.setJourney(null, "", "");
            return;
        }
        Train train = (Train) trainCombo.getSelectedItem();
        String className = ((String) classCombo.getSelectedItem()).substring(5);
        journeyPanel.setJourney(train, className, "");
        if (train == null) {
            setAvailability("No direct train on this route", UiUtil.ERROR_RED);
            return;
        }
        LocalDate date;
        try {
            date = Validator.parseFutureDate(dateField.getText(), "Journey date", LocalDate.now(),
                    ReservationSystem.ADVANCE_BOOKING_DAYS);
        } catch (ValidationException ex) {
            setAvailability("Enter a valid journey date", UiUtil.WARN_ORANGE);
            return;
        }
        journeyPanel.setJourney(train, className, date.format(java.time.format.DateTimeFormatter
                .ofPattern("EEE, dd MMM", java.util.Locale.ENGLISH)));
        String classCode = selectedClassCode();
        int free = system.getAvailableSeats(train, classCode, date);
        if (free > 0) {
            setAvailability("AVAILABLE  " + free + " of " + ReservationSystem.seatsInClass(classCode) + " berths",
                    UiUtil.OK_GREEN);
        } else {
            int waiting = system.getWaitingCount(train, classCode, date);
            if (waiting >= ReservationSystem.MAX_WAITING_LIST) {
                setAvailability("REGRET - waiting list full", UiUtil.ERROR_RED);
            } else {
                setAvailability("FULL - next ticket gets WL " + (waiting + 1), UiUtil.WARN_ORANGE);
            }
        }
    }

    private void setAvailability(String text, Color color) {
        availabilityLabel.setText(text);
        availabilityLabel.setForeground(color);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Ticket t : system.getBookings()) {
            tableModel.addRow(new Object[] {
                t.getPnr(),
                t.getPassenger().getName(),
                t.getPassenger().getAge(),
                t.getTrain().getNumber() + " " + t.getTrain().getName(),
                t.getClassCode(),
                t.getJourneyDate().format(Validator.DATE_FORMAT),
                t.getStatusText(),
                Money.plain(t.getTotalFare())
            });
        }
    }

    private void showTicket(Ticket ticket) {
        ticketArea.setText(ticket.toTicketText());
        ticketArea.setCaretPosition(0);
    }

    private String selectedGender() {
        if (maleRadio.isSelected()) {
            return "Male";
        }
        if (femaleRadio.isSelected()) {
            return "Female";
        }
        if (otherRadio.isSelected()) {
            return "Other";
        }
        return null;
    }

    private String selectedClassCode() {
        return ((String) classCombo.getSelectedItem()).substring(0, 2);
    }

    private void setStatus(String text) {
        statusBar.setText(" " + text);
    }

    private static String welcomeText() {
        return "\n  Welcome to the Railway Reservation System\n\n"
                + "  1. Fill in the passenger and journey details.\n"
                + "  2. Click 'Check Fare' to see the fare breakup.\n"
                + "  3. Click 'Book Ticket' to get your PNR.\n"
                + "  4. Select a booking below and click\n"
                + "     'Cancel Ticket' to cancel it with a refund.\n\n"
                + "  Concessions on base fare:\n"
                + "     Senior citizen (60+ years)   40% off\n"
                + "     Child (5-11 years)           50% off\n\n"
                + "  When a class is full, tickets go on the\n"
                + "  waiting list (WL) and are confirmed\n"
                + "  automatically when someone cancels.\n";
    }

    /** Colours the Status column: green = confirmed, orange = waiting, red = cancelled. */
    private static final class StatusRenderer extends DefaultTableCellRenderer {
        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            String status = String.valueOf(value);
            if (!selected) {
                if (status.startsWith("CNF")) {
                    c.setForeground(UiUtil.OK_GREEN);
                } else if (status.startsWith("WL")) {
                    c.setForeground(UiUtil.WARN_ORANGE);
                } else {
                    c.setForeground(UiUtil.ERROR_RED);
                }
            }
            c.setFont(c.getFont().deriveFont(Font.BOLD));
            return c;
        }
    }
}
