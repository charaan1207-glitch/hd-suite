import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The shop's catalogue and order desk. No GUI code, so it can be tested on its own. */
public class Store {

    public static final String[] CATEGORIES = {"All", "Electronics", "Clothing", "Books", "Grocery"};

    private static final String LINE = "==================================================\n";
    private static final String THIN = "--------------------------------------------------\n";
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    private final List<Product> products = new ArrayList<Product>();
    private int nextOrderNumber = 1001;
    private int ordersPlaced;
    private String lastOrderId;

    public Store() {
        // Demo catalogue: price, stock, then MRP / rating / reviews / badge for the product card
        products.add(new Electronics("E101", "Wireless Earbuds", 1499, 15, "SoundMax", 12)
                .withListing(2999, 4.3, 12840, "Bestseller"));
        products.add(new Electronics("E102", "Android Smartphone 128GB", 12999, 5, "Nova", 12)
                .withListing(15999, 4.4, 8650, "New"));
        products.add(new Electronics("E103", "Power Bank 10000mAh", 899, 20, "VoltGo", 6)
                .withListing(1499, 4.2, 23110, null));
        products.add(new Electronics("E104", "Smart Watch", 2499, 8, "FitPulse", 12)
                .withListing(4999, 4.1, 5420, "Deal"));
        products.add(new Clothing("C201", "Cotton T-Shirt", 499, 30, "S, M, L, XL, XXL", "100% cotton")
                .withListing(799, 4.0, 3210, null));
        products.add(new Clothing("C202", "Slim Fit Jeans", 1299, 12, "28 - 36", "Denim")
                .withListing(1999, 4.2, 1980, null));
        products.add(new Clothing("C203", "Winter Hoodie", 1799, 6, "M, L, XL", "Fleece")
                .withListing(2499, 4.5, 960, "Winter pick"));
        products.add(new Book("B301", "Java: The Complete Reference", 899, 10, "Herbert Schildt")
                .withListing(1099, 4.6, 4120, "Bestseller"));
        products.add(new Book("B302", "Head First Java", 749, 7, "Kathy Sierra & Bert Bates")
                .withListing(899, 4.7, 2870, null));
        products.add(new Book("B303", "Clean Code", 649, 4, "Robert C. Martin")
                .withListing(799, 4.7, 6530, null));
        products.add(new Grocery("G401", "Basmati Rice", 549, 25, "5 kg")
                .withListing(649, 4.3, 15400, null));
        products.add(new Grocery("G402", "Green Tea (100 bags)", 299, 18, "100 bags")
                .withListing(399, 4.2, 7800, null));
        products.add(new Grocery("G403", "California Almonds", 449, 3, "500 g")
                .withListing(599, 4.4, 3300, null));
    }

    public String getLastOrderId() {
        return lastOrderId;
    }

    /** Products in a category ("All" for every category) whose name contains the keyword. */
    public List<Product> search(String category, String keyword) {
        String key = keyword == null ? "" : keyword.trim().toLowerCase();
        List<Product> result = new ArrayList<Product>();
        for (Product p : products) {
            boolean categoryMatches = category == null || "All".equals(category) || p.getCategory().equals(category);
            if (categoryMatches && p.getName().toLowerCase().contains(key)) {
                result.add(p);
            }
        }
        return result;
    }

    public int getOrdersPlaced() {
        return ordersPlaced;
    }

    /**
     * Places the order: re-checks stock, reduces stock, empties the cart and
     * returns the printable receipt. Customer details must already be validated.
     */
    public String placeOrder(ShoppingCart cart, String name, String mobile, String address, String pincode)
            throws ValidationException {
        if (cart.isEmpty()) {
            throw new ValidationException("Your cart is empty.");
        }
        for (CartItem item : cart.getItems()) {
            if (item.getQuantity() > item.getProduct().getStock()) {
                throw new ValidationException("Only " + item.getProduct().getStock() + " unit(s) of "
                        + item.getProduct().getName() + " are left. Please update your cart.");
            }
        }

        String orderId = "OD" + nextOrderNumber;
        String receipt = buildReceipt(orderId, cart, name, mobile, address, pincode);
        for (CartItem item : cart.getItems()) {
            item.getProduct().reduceStock(item.getQuantity());
        }
        lastOrderId = orderId;
        nextOrderNumber++;
        ordersPlaced++;
        cart.clear();
        return receipt;
    }

    private String buildReceipt(String orderId, ShoppingCart cart, String name, String mobile,
                                String address, String pincode) {
        StringBuilder sb = new StringBuilder();
        sb.append(LINE);
        sb.append("            HD CART  -  ORDER RECEIPT\n");
        sb.append(LINE);
        sb.append("Order ID   : ").append(orderId).append('\n');
        sb.append("Date       : ").append(LocalDateTime.now().format(TIME_FORMAT)).append('\n');
        sb.append("Customer   : ").append(name).append('\n');
        sb.append("Mobile     : ").append(mobile).append('\n');
        sb.append("Deliver to : ").append(address).append(" - ").append(pincode).append('\n');
        sb.append("Payment    : ").append(cart.getPaymentMode()).append('\n');
        sb.append(THIN);
        sb.append(String.format(Locale.ENGLISH, "%-24s %4s %9s %10s\n", "Item", "Qty", "Price", "Total"));
        for (CartItem item : cart.getItems()) {
            String itemName = item.getProduct().getName();
            if (itemName.length() > 24) {
                itemName = itemName.substring(0, 21) + "...";
            }
            sb.append(String.format(Locale.ENGLISH, "%-24s %4d %9.2f %10.2f\n",
                    itemName, item.getQuantity(), item.getProduct().getPrice(), item.getSubtotal()));
        }
        sb.append(THIN);
        amount(sb, "Subtotal", cart.getSubtotal());
        amount(sb, "Tax", cart.getTax());
        if (cart.getDiscount() > 0) {
            amount(sb, "Discount (" + cart.getCoupon().getCode() + ")", -cart.getDiscount());
        }
        amount(sb, "Delivery", cart.getDeliveryCharge());
        if (cart.getOtherCharges() > 0) {
            amount(sb, "Gift wrap / COD charges", cart.getOtherCharges());
        }
        sb.append(THIN);
        amount(sb, "GRAND TOTAL", cart.getGrandTotal());
        sb.append(LINE);
        sb.append("Expected delivery: ").append(LocalDate.now().plusDays(3).format(Validator.DATE_FORMAT)).append('\n');
        sb.append("        Thank you for shopping with us!\n");
        return sb.toString();
    }

    private static void amount(StringBuilder sb, String label, double value) {
        sb.append(String.format(Locale.ENGLISH, "%-35sRs %10.2f\n", label, value));
    }
}
