/** One line in the shopping cart: a product and how many of it. */
public class CartItem {

    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getSubtotal() {
        return Money.round(product.getPrice() * quantity);
    }

    /** Polymorphic call: each product category returns its own tax rate. */
    public double getTax() {
        return Money.round(getSubtotal() * product.getTaxPercent() / 100.0);
    }

    public double getTotal() {
        return Money.round(getSubtotal() + getTax());
    }
}
