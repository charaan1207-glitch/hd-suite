import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Base class of every railway ticket.
 *
 * Each travel class (Sleeper, AC 3 Tier, AC 2 Tier) is a subclass that
 * overrides the fare rules (rate per km, reservation charge, GST, berth layout).
 * The fare is always calculated here, in one place, by calling those overridden
 * methods - this is runtime polymorphism.
 */
public abstract class Ticket {

    public enum Status { CONFIRMED, WAITING, CANCELLED }

    public static final double INSURANCE_PREMIUM = 10.0;

    private static final String LINE = "==================================================\n";
    private static final String THIN = "--------------------------------------------------\n";

    private final String pnr;
    private final Passenger passenger;
    private final Train train;
    private final LocalDate journeyDate;
    private final String berthPreference;
    private final boolean mealsIncluded;
    private final boolean insuranceIncluded;

    private Status status;          // null while it is only a fare enquiry
    private int seatNumber;         // set when CONFIRMED
    private int waitingNumber;      // set when WAITING
    private double refundAmount;    // set when CANCELLED

    protected Ticket(String pnr, Passenger passenger, Train train, LocalDate journeyDate,
                     String berthPreference, boolean mealsIncluded, boolean insuranceIncluded) {
        this.pnr = pnr;
        this.passenger = passenger;
        this.train = train;
        this.journeyDate = journeyDate;
        this.berthPreference = berthPreference;
        this.mealsIncluded = mealsIncluded;
        this.insuranceIncluded = insuranceIncluded;
    }

    // ---------- rules that every travel class must define ----------

    public abstract String getClassCode();

    public abstract String getClassName();

    /** Number of berths in this class on one train (kept small so the waiting list is easy to demo). */
    public abstract int getTotalSeats();

    protected abstract double getRatePerKm();

    protected abstract double getReservationCharge();

    protected abstract double getGstPercent();

    protected abstract String getCoachCode();

    public abstract double getCancellationCharge();

    // ---------- rules a subclass MAY override ----------

    protected double getMealPrice() {
        return 150.0;
    }

    /** Sleeper / AC 3 Tier bay: Lower, Middle, Upper x2, then Side Lower, Side Upper. */
    public String getBerthType(int seat) {
        String[] bay = {"LB", "MB", "UB", "LB", "MB", "UB", "SL", "SU"};
        return bay[(seat - 1) % bay.length];
    }

    // ---------- fare calculation (same for every class) ----------

    public double getBaseFare() {
        return Money.round(train.getDistanceKm() * getRatePerKm());
    }

    public int getConcessionPercent() {
        if (passenger.isSeniorCitizen()) {
            return 40;
        }
        if (passenger.isChild()) {
            return 50;
        }
        return 0;
    }

    public double getConcession() {
        return Money.round(getBaseFare() * getConcessionPercent() / 100.0);
    }

    public double getGst() {
        return Money.round((getBaseFare() - getConcession()) * getGstPercent() / 100.0);
    }

    public double getAddOnCharges() {
        double total = 0;
        if (mealsIncluded) {
            total += getMealPrice();
        }
        if (insuranceIncluded) {
            total += INSURANCE_PREMIUM;
        }
        return total;
    }

    public double getTotalFare() {
        return Money.round(getBaseFare() - getConcession() + getReservationCharge() + getGst() + getAddOnCharges());
    }

    // ---------- status changes (called only by ReservationSystem) ----------

    void confirm(int seat) {
        status = Status.CONFIRMED;
        seatNumber = seat;
        waitingNumber = 0;
    }

    void waitlist(int position) {
        status = Status.WAITING;
        waitingNumber = position;
        seatNumber = 0;
    }

    void cancel(double refund) {
        status = Status.CANCELLED;
        refundAmount = refund;
        seatNumber = 0;
        waitingNumber = 0;
    }

    // ---------- getters ----------

    public String getPnr() {
        return pnr;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public Train getTrain() {
        return train;
    }

    public LocalDate getJourneyDate() {
        return journeyDate;
    }

    public String getBerthPreference() {
        return berthPreference;
    }

    public Status getStatus() {
        return status;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public int getWaitingNumber() {
        return waitingNumber;
    }

    public double getRefundAmount() {
        return refundAmount;
    }

    public String getStatusText() {
        if (status == null) {
            return "Not booked yet (fare enquiry)";
        }
        switch (status) {
            case CONFIRMED:
                return "CNF " + getCoachCode() + "/" + seatNumber + "/" + getBerthType(seatNumber);
            case WAITING:
                return "WL " + waitingNumber;
            default:
                return "CANCELLED";
        }
    }

    /** The printable e-ticket shown in the preview area. */
    public String toTicketText() {
        StringBuilder sb = new StringBuilder();
        sb.append(LINE);
        sb.append("         HD RAIL  -  E-TICKET (DEMO)\n");
        sb.append(LINE);
        row(sb, "PNR No.", pnr);
        row(sb, "Train", train.getNumber() + " - " + train.getName());
        row(sb, "From", train.getSource() + "  (dep " + train.getDeparture() + ")");
        row(sb, "To", train.getDestination() + "  (arr " + train.getArrival() + ")");
        row(sb, "Journey date", journeyDate.format(Validator.DATE_FORMAT) + " ("
                + journeyDate.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH) + ")");
        row(sb, "Class", getClassName() + " (" + getClassCode() + ")");
        sb.append(THIN);
        row(sb, "Passenger", passenger.getName());
        row(sb, "Age / Gender", passenger.getAge() + " / " + passenger.getGender());
        row(sb, "Mobile", passenger.getMobile());
        row(sb, "Berth pref.", berthPreference);
        row(sb, "Status", getStatusText());
        sb.append(THIN);
        amount(sb, String.format(Locale.ENGLISH, "Base fare (%d km x %.2f)", train.getDistanceKm(), getRatePerKm()),
                getBaseFare());
        if (getConcessionPercent() > 0) {
            String who = passenger.isSeniorCitizen() ? "senior citizen" : "child";
            amount(sb, "Concession (" + getConcessionPercent() + "%, " + who + ")", -getConcession());
        }
        amount(sb, "Reservation charge", getReservationCharge());
        if (getGst() > 0) {
            amount(sb, String.format(Locale.ENGLISH, "GST (%.0f%%)", getGstPercent()), getGst());
        }
        if (mealsIncluded) {
            amount(sb, "Meals", getMealPrice());
        }
        if (insuranceIncluded) {
            amount(sb, "Travel insurance", INSURANCE_PREMIUM);
        }
        sb.append(THIN);
        amount(sb, "TOTAL FARE", getTotalFare());
        if (status == Status.CANCELLED) {
            amount(sb, "Cancellation charge", -(getTotalFare() - refundAmount));
            amount(sb, "REFUND", refundAmount);
        }
        sb.append(LINE);
        return sb.toString();
    }

    private static void row(StringBuilder sb, String label, String value) {
        sb.append(String.format(Locale.ENGLISH, "%-13s: %s\n", label, value));
    }

    private static void amount(StringBuilder sb, String label, double value) {
        sb.append(String.format(Locale.ENGLISH, "%-33sRs %10.2f\n", label, value));
    }
}
