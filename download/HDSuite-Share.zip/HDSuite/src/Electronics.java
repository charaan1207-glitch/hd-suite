/** Electronic gadgets: 18% tax, come with a brand and warranty. */
public class Electronics extends Product {

    private final String brand;
    private final int warrantyMonths;

    public Electronics(String id, String name, double price, int stock, String brand, int warrantyMonths) {
        super(id, name, price, stock);
        this.brand = brand;
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public String getCategory() {
        return "Electronics";
    }

    @Override
    public double getTaxPercent() {
        return 18.0;
    }

    @Override
    public String getSpecialInfo() {
        return "Brand      : " + brand + "\n"
                + "Warranty   : " + warrantyMonths + " months";
    }
}
