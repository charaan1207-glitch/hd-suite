import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The customer's cart: items, coupon, delivery and payment options, and all the totals. */
public class ShoppingCart {

    public static final int MAX_QUANTITY_PER_ADD = 10;
    public static final double FREE_DELIVERY_ABOVE = 999.0;
    public static final double DELIVERY_FEE = 49.0;
    public static final double GIFT_WRAP_FEE = 50.0;
    public static final double COD_FEE = 40.0;
    public static final String PAY_UPI = "UPI";
    public static final String PAY_CARD = "Debit / Credit Card";
    public static final String PAY_COD = "Cash on Delivery";

    private final List<CartItem> items = new ArrayList<CartItem>();
    private Coupon coupon;
    private boolean giftWrap;
    private String paymentMode = PAY_UPI;

    public void add(Product product, int quantity) throws ValidationException {
        if (product == null) {
            throw new ValidationException("Please select a product first.");
        }
        if (quantity < 1 || quantity > MAX_QUANTITY_PER_ADD) {
            throw new ValidationException("Quantity must be between 1 and " + MAX_QUANTITY_PER_ADD + ".");
        }
        if (product.getStock() == 0) {
            throw new ValidationException(product.getName() + " is out of stock.");
        }
        CartItem existing = find(product);
        int already = existing == null ? 0 : existing.getQuantity();
        if (already + quantity > product.getStock()) {
            String message = "Only " + product.getStock() + " unit(s) of " + product.getName() + " are in stock";
            message += already > 0 ? " and you already have " + already + " in your cart." : ".";
            throw new ValidationException(message);
        }
        if (existing == null) {
            items.add(new CartItem(product, quantity));
        } else {
            existing.setQuantity(already + quantity);
        }
    }

    public void updateQuantity(int index, int quantity) throws ValidationException {
        CartItem item = getItem(index);
        if (quantity < 1) {
            throw new ValidationException("Quantity must be at least 1. Use 'Remove Item' to take it out of the cart.");
        }
        if (quantity > item.getProduct().getStock()) {
            throw new ValidationException("Only " + item.getProduct().getStock() + " unit(s) of "
                    + item.getProduct().getName() + " are in stock.");
        }
        item.setQuantity(quantity);
    }

    public CartItem remove(int index) throws ValidationException {
        CartItem item = getItem(index);
        items.remove(index);
        if (items.isEmpty()) {
            coupon = null;
        }
        return item;
    }

    public void clear() {
        items.clear();
        coupon = null;
        giftWrap = false;
        paymentMode = PAY_UPI;
    }

    public void applyCoupon(String code) throws ValidationException {
        if (items.isEmpty()) {
            throw new ValidationException("Add some items to your cart before applying a coupon.");
        }
        Coupon found = Coupon.find(code);
        if (!found.isEligible(getSubtotal())) {
            throw new ValidationException("Coupon " + found.getCode() + " needs a minimum order of "
                    + Money.format(found.getMinimumSubtotal()) + ". Your subtotal is " + Money.format(getSubtotal()) + ".");
        }
        coupon = found;
    }

    public void removeCoupon() {
        coupon = null;
    }

    // ---------- totals ----------

    public double getSubtotal() {
        double sum = 0;
        for (CartItem item : items) {
            sum += item.getSubtotal();
        }
        return Money.round(sum);
    }

    public double getTax() {
        double sum = 0;
        for (CartItem item : items) {
            sum += item.getTax();
        }
        return Money.round(sum);
    }

    /** 0 if there is no coupon, or if items were removed and the coupon no longer qualifies. */
    public double getDiscount() {
        if (coupon == null || !coupon.isEligible(getSubtotal())) {
            return 0;
        }
        return coupon.discountOn(getSubtotal());
    }

    public double getDeliveryCharge() {
        if (items.isEmpty() || getSubtotal() >= FREE_DELIVERY_ABOVE) {
            return 0;
        }
        return DELIVERY_FEE;
    }

    public double getOtherCharges() {
        if (items.isEmpty()) {
            return 0;
        }
        double charges = 0;
        if (giftWrap) {
            charges += GIFT_WRAP_FEE;
        }
        if (PAY_COD.equals(paymentMode)) {
            charges += COD_FEE;
        }
        return charges;
    }

    public double getGrandTotal() {
        return Money.round(getSubtotal() + getTax() - getDiscount() + getDeliveryCharge() + getOtherCharges());
    }

    // ---------- getters / setters ----------

    public List<CartItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public int getTotalQuantity() {
        int total = 0;
        for (CartItem item : items) {
            total += item.getQuantity();
        }
        return total;
    }

    public Coupon getCoupon() {
        return coupon;
    }

    public boolean isGiftWrap() {
        return giftWrap;
    }

    public void setGiftWrap(boolean giftWrap) {
        this.giftWrap = giftWrap;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    private CartItem find(Product product) {
        for (CartItem item : items) {
            if (item.getProduct() == product) {
                return item;
            }
        }
        return null;
    }

    private CartItem getItem(int index) throws ValidationException {
        if (index < 0 || index >= items.size()) {
            throw new ValidationException("Please select an item in your cart first.");
        }
        return items.get(index);
    }
}
