import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.Icon;

/**
 * All pictures in the application are drawn here with Java 2D graphics,
 * so the project needs no image files. Every drawing is designed on a
 * 100 x 100 grid and scaled to the size asked for.
 */
public final class Art {

    private Art() {
    }

    /** Picture of a product, chosen by its product ID. */
    public static Icon product(String productId, int width, int height) {
        return new ProductIcon(productId, width, height);
    }

    public static Icon cart(int size, Color color) {
        return new DesignIcon(size, size) {
            @Override
            void draw(Graphics2D g) {
                g.setColor(color);
                g.setStroke(new BasicStroke(7, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                Path2D basket = new Path2D.Double();
                basket.moveTo(6, 16);
                basket.lineTo(20, 16);
                basket.lineTo(32, 66);
                basket.lineTo(80, 66);
                basket.lineTo(92, 30);
                basket.lineTo(26, 30);
                g.draw(basket);
                g.fill(new Ellipse2D.Double(30, 76, 14, 14));
                g.fill(new Ellipse2D.Double(68, 76, 14, 14));
            }
        };
    }

    public static Icon train(int width, int height, Color color) {
        return new DesignIcon(width, height) {
            @Override
            void draw(Graphics2D g) {
                Path2D body = new Path2D.Double();
                body.moveTo(4, 30);
                body.lineTo(70, 30);
                body.quadTo(96, 32, 97, 62);
                body.lineTo(97, 72);
                body.lineTo(4, 72);
                body.closePath();
                g.setColor(color);
                g.fill(body);
                g.setColor(new Color(255, 255, 255, 230));
                for (int i = 0; i < 4; i++) {
                    g.fill(new RoundRectangle2D.Double(10 + i * 15, 38, 10, 12, 3, 3));
                }
                g.fill(new RoundRectangle2D.Double(73, 38, 14, 14, 4, 4));
                g.setColor(new Color(255, 200, 40));
                g.fill(new Rectangle2D.Double(4, 58, 93, 4));
                g.setColor(new Color(50, 55, 65));
                for (int x : new int[] {14, 32, 62, 80}) {
                    g.fill(new Ellipse2D.Double(x, 68, 12, 12));
                }
                g.fill(new Rectangle2D.Double(0, 82, 100, 3));
            }
        };
    }

    /** Green circle with a white tick, used on the order-placed screen. */
    public static Icon check(int size) {
        return new DesignIcon(size, size) {
            @Override
            void draw(Graphics2D g) {
                g.setColor(new Color(46, 160, 67));
                g.fill(new Ellipse2D.Double(4, 4, 92, 92));
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                Path2D tick = new Path2D.Double();
                tick.moveTo(28, 52);
                tick.lineTo(44, 68);
                tick.lineTo(73, 35);
                g.draw(tick);
            }
        };
    }

    /** Five stars, filled according to the rating (e.g. 4.3 fills four and a third). */
    public static Icon stars(final double rating, final int starSize) {
        return new Icon() {
            @Override
            public int getIconWidth() {
                return starSize * 5 + 8;
            }

            @Override
            public int getIconHeight() {
                return starSize;
            }

            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = smooth(g);
                for (int i = 0; i < 5; i++) {
                    Shape star = star(x + i * (starSize + 2) + starSize / 2.0, y + starSize / 2.0, starSize / 2.0);
                    g2.setColor(new Color(220, 222, 228));
                    g2.fill(star);
                    double fill = Math.max(0, Math.min(1, rating - i));
                    if (fill > 0) {
                        Graphics2D part = (Graphics2D) g2.create();
                        part.clip(new Rectangle2D.Double(x + i * (starSize + 2), y, starSize * fill, starSize));
                        part.setColor(new Color(255, 167, 38));
                        part.fill(star);
                        part.dispose();
                    }
                }
                g2.dispose();
            }
        };
    }

    private static Shape star(double cx, double cy, double r) {
        Path2D p = new Path2D.Double();
        for (int i = 0; i < 10; i++) {
            double radius = i % 2 == 0 ? r : r * 0.45;
            double angle = Math.PI / 2 + i * Math.PI / 5;
            double px = cx + radius * Math.cos(angle);
            double py = cy - radius * Math.sin(angle);
            if (i == 0) {
                p.moveTo(px, py);
            } else {
                p.lineTo(px, py);
            }
        }
        p.closePath();
        return p;
    }

    static Graphics2D smooth(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        return g2;
    }

    /** Base for icons drawn on a 100 x 100 design grid. */
    private abstract static class DesignIcon implements Icon {
        private final int width;
        private final int height;

        DesignIcon(int width, int height) {
            this.width = width;
            this.height = height;
        }

        abstract void draw(Graphics2D g);

        @Override
        public int getIconWidth() {
            return width;
        }

        @Override
        public int getIconHeight() {
            return height;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = smooth(g);
            double scale = Math.min(width, height) / 100.0;
            g2.translate(x + (width - 100 * scale) / 2, y + (height - 100 * scale) / 2);
            g2.scale(scale, scale);
            draw(g2);
            g2.dispose();
        }
    }

    /** Product pictures on a soft, category-coloured background. */
    private static final class ProductIcon implements Icon {
        private final String id;
        private final int width;
        private final int height;

        ProductIcon(String id, int width, int height) {
            this.id = id;
            this.width = width;
            this.height = height;
        }

        @Override
        public int getIconWidth() {
            return width;
        }

        @Override
        public int getIconHeight() {
            return height;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = smooth(g);
            g2.translate(x, y);
            Color bg = background(id.charAt(0));
            g2.setPaint(new GradientPaint(0, 0, bg.brighter(), 0, height, bg));
            double arc = Math.min(width, height) * 0.14;
            g2.fill(new RoundRectangle2D.Double(0, 0, width, height, arc, arc));
            double scale = Math.min(width, height) * 0.86 / 100.0;
            g2.translate((width - 100 * scale) / 2, (height - 100 * scale) / 2);
            g2.scale(scale, scale);
            drawProduct(g2);
            g2.dispose();
        }

        private static Color background(char category) {
            switch (category) {
                case 'E':
                    return new Color(219, 233, 252);
                case 'C':
                    return new Color(253, 230, 216);
                case 'B':
                    return new Color(233, 226, 250);
                default:
                    return new Color(220, 243, 228);
            }
        }

        private void drawProduct(Graphics2D g) {
            if ("E101".equals(id)) {
                earbuds(g);
            } else if ("E102".equals(id)) {
                phone(g);
            } else if ("E103".equals(id)) {
                powerBank(g);
            } else if ("E104".equals(id)) {
                watch(g);
            } else if ("C201".equals(id)) {
                tShirt(g);
            } else if ("C202".equals(id)) {
                jeans(g);
            } else if ("C203".equals(id)) {
                hoodie(g);
            } else if ("B301".equals(id)) {
                book(g, new Color(196, 52, 40), "JAVA", "Complete Ref.");
            } else if ("B302".equals(id)) {
                book(g, new Color(30, 120, 190), "Head First", "Java");
            } else if ("B303".equals(id)) {
                book(g, new Color(55, 60, 72), "Clean", "Code");
            } else if ("G401".equals(id)) {
                riceBag(g);
            } else if ("G402".equals(id)) {
                teaBox(g);
            } else if ("G403".equals(id)) {
                almondJar(g);
            } else {
                g.setColor(new Color(170, 140, 100));
                g.fill(new RoundRectangle2D.Double(25, 25, 50, 50, 8, 8));
            }
        }

        private static void shadow(Graphics2D g, double x, double w) {
            g.setColor(new Color(0, 0, 0, 30));
            g.fill(new Ellipse2D.Double(x, 90, w, 7));
        }

        private static void outline(Graphics2D g, Shape s, Color fill, Color line) {
            g.setColor(fill);
            g.fill(s);
            g.setColor(line);
            g.setStroke(new BasicStroke(1.6f));
            g.draw(s);
        }

        private static void centered(Graphics2D g, String text, double cx, double baseline, int size, int style, Color color) {
            g.setFont(new Font("Segoe UI", style, size));
            g.setColor(color);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(text, (float) (cx - fm.stringWidth(text) / 2.0), (float) baseline);
        }

        private static void earbuds(Graphics2D g) {
            shadow(g, 20, 60);
            Color line = new Color(170, 176, 188);
            outline(g, new RoundRectangle2D.Double(20, 50, 60, 40, 22, 22), Color.WHITE, line);
            g.setColor(line);
            g.draw(new java.awt.geom.Line2D.Double(22, 63, 78, 63));
            g.setColor(new Color(76, 175, 80));
            g.fill(new Ellipse2D.Double(47, 76, 6, 6));
            outline(g, new RoundRectangle2D.Double(33, 26, 9, 24, 8, 8), Color.WHITE, line);
            outline(g, new RoundRectangle2D.Double(58, 26, 9, 24, 8, 8), Color.WHITE, line);
            outline(g, new Ellipse2D.Double(22, 8, 24, 24), Color.WHITE, line);
            outline(g, new Ellipse2D.Double(54, 8, 24, 24), Color.WHITE, line);
            g.setColor(new Color(60, 64, 72));
            g.fill(new Ellipse2D.Double(28, 15, 10, 10));
            g.fill(new Ellipse2D.Double(62, 15, 10, 10));
        }

        private static void phone(Graphics2D g) {
            shadow(g, 28, 46);
            g.setColor(new Color(36, 40, 52));
            g.fill(new RoundRectangle2D.Double(29, 4, 42, 88, 14, 14));
            g.setPaint(new GradientPaint(33, 10, new Color(123, 97, 255), 67, 86, new Color(0, 188, 212)));
            g.fill(new RoundRectangle2D.Double(32, 8, 36, 80, 9, 9));
            g.setColor(new Color(36, 40, 52));
            g.fill(new RoundRectangle2D.Double(44, 10, 12, 4, 4, 4));
            centered(g, "12:45", 50, 30, 9, Font.BOLD, Color.WHITE);
            g.setColor(new Color(255, 255, 255, 170));
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    g.fill(new RoundRectangle2D.Double(36 + col * 10, 42 + row * 11, 7, 7, 3, 3));
                }
            }
            g.fill(new RoundRectangle2D.Double(43, 82, 14, 2, 2, 2));
        }

        private static void powerBank(Graphics2D g) {
            shadow(g, 18, 64);
            g.setPaint(new GradientPaint(0, 24, new Color(84, 90, 104), 0, 80, new Color(48, 52, 62)));
            g.fill(new RoundRectangle2D.Double(16, 24, 64, 58, 14, 14));
            g.setColor(new Color(30, 32, 38));
            g.fill(new RoundRectangle2D.Double(80, 44, 5, 16, 2, 2));
            centered(g, "10000", 47, 47, 14, Font.BOLD, Color.WHITE);
            centered(g, "mAh", 47, 58, 8, Font.PLAIN, new Color(200, 205, 215));
            for (int i = 0; i < 4; i++) {
                g.setColor(i < 3 ? new Color(102, 220, 120) : new Color(110, 116, 128));
                g.fill(new RoundRectangle2D.Double(29 + i * 10, 66, 7, 7, 2, 2));
            }
        }

        private static void watch(Graphics2D g) {
            shadow(g, 30, 40);
            g.setColor(new Color(52, 58, 70));
            g.fill(new RoundRectangle2D.Double(37, 2, 26, 30, 6, 6));
            g.fill(new RoundRectangle2D.Double(37, 68, 26, 26, 6, 6));
            g.setColor(new Color(20, 22, 28));
            g.fill(new RoundRectangle2D.Double(27, 24, 46, 52, 16, 16));
            g.setColor(new Color(150, 156, 168));
            g.fill(new RoundRectangle2D.Double(73, 42, 5, 14, 2, 2));
            g.setPaint(new GradientPaint(30, 28, new Color(18, 40, 80), 70, 72, new Color(10, 16, 30)));
            g.fill(new RoundRectangle2D.Double(31, 28, 38, 44, 11, 11));
            g.setColor(new Color(0, 230, 160));
            g.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(new java.awt.geom.Arc2D.Double(37, 35, 26, 26, 90, -250, java.awt.geom.Arc2D.OPEN));
            centered(g, "10:09", 50, 52, 9, Font.BOLD, Color.WHITE);
            centered(g, "8,240 steps", 50, 68, 5, Font.PLAIN, new Color(170, 200, 230));
        }

        private static void tShirt(Graphics2D g) {
            shadow(g, 26, 48);
            Path2D p = new Path2D.Double();
            p.moveTo(36, 12);
            p.lineTo(43, 10);
            p.quadTo(50, 19, 57, 10);
            p.lineTo(64, 12);
            p.lineTo(86, 30);
            p.lineTo(75, 44);
            p.lineTo(67, 38);
            p.lineTo(67, 88);
            p.lineTo(33, 88);
            p.lineTo(33, 38);
            p.lineTo(25, 44);
            p.lineTo(14, 30);
            p.closePath();
            outline(g, p, new Color(229, 75, 75), new Color(180, 50, 50));
            g.setColor(new Color(255, 255, 255, 220));
            centered(g, "CODE", 50, 58, 10, Font.BOLD, new Color(255, 255, 255, 230));
        }

        private static void jeans(Graphics2D g) {
            shadow(g, 22, 56);
            Path2D p = new Path2D.Double();
            p.moveTo(30, 8);
            p.lineTo(70, 8);
            p.lineTo(77, 90);
            p.lineTo(56, 90);
            p.lineTo(50, 40);
            p.lineTo(44, 90);
            p.lineTo(23, 90);
            p.closePath();
            outline(g, p, new Color(55, 98, 160), new Color(35, 66, 115));
            g.setColor(new Color(40, 72, 125));
            g.fill(new Rectangle2D.Double(30, 8, 40, 8));
            g.setColor(new Color(230, 170, 70));
            g.fill(new Ellipse2D.Double(47.5, 9.5, 5, 5));
            g.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                    1f, new float[] {2.5f, 2f}, 0));
            g.draw(new java.awt.geom.QuadCurve2D.Double(33, 18, 36, 28, 44, 18));
            g.draw(new java.awt.geom.QuadCurve2D.Double(56, 18, 64, 28, 67, 18));
            g.draw(new java.awt.geom.Line2D.Double(50, 16, 50, 38));
        }

        private static void hoodie(Graphics2D g) {
            shadow(g, 20, 60);
            Color fill = new Color(96, 108, 124);
            Color line = new Color(66, 76, 90);
            outline(g, new Ellipse2D.Double(35, 4, 30, 24), new Color(84, 96, 112), line);
            Path2D p = new Path2D.Double();
            p.moveTo(36, 18);
            p.lineTo(25, 22);
            p.lineTo(12, 72);
            p.lineTo(23, 75);
            p.lineTo(32, 46);
            p.lineTo(32, 90);
            p.lineTo(68, 90);
            p.lineTo(68, 46);
            p.lineTo(77, 75);
            p.lineTo(88, 72);
            p.lineTo(75, 22);
            p.lineTo(64, 18);
            p.closePath();
            outline(g, p, fill, line);
            g.setColor(new Color(40, 46, 56));
            g.fill(new Ellipse2D.Double(42, 12, 16, 12));
            outline(g, new RoundRectangle2D.Double(38, 62, 24, 15, 6, 6), new Color(84, 96, 112), line);
            g.setColor(Color.WHITE);
            g.setStroke(new BasicStroke(1.4f));
            g.draw(new java.awt.geom.Line2D.Double(46, 24, 45, 40));
            g.draw(new java.awt.geom.Line2D.Double(54, 24, 55, 40));
        }

        private static void book(Graphics2D g, Color cover, String title, String subtitle) {
            shadow(g, 26, 56);
            g.setColor(new Color(250, 246, 232));
            g.fill(new Rectangle2D.Double(72, 8, 8, 82));
            g.setColor(new Color(214, 206, 186));
            for (int y = 12; y < 88; y += 4) {
                g.draw(new java.awt.geom.Line2D.Double(73, y, 79, y));
            }
            g.setColor(cover);
            g.fill(new RoundRectangle2D.Double(22, 6, 54, 86, 5, 5));
            g.setColor(cover.darker());
            g.fill(new Rectangle2D.Double(22, 6, 8, 86));
            g.setColor(new Color(255, 255, 255, 60));
            g.fill(new Rectangle2D.Double(34, 18, 36, 2));
            g.fill(new Rectangle2D.Double(34, 74, 36, 2));
            centered(g, title, 52, 42, title.length() > 6 ? 9 : 14, Font.BOLD, Color.WHITE);
            centered(g, subtitle, 52, 56, 8, Font.PLAIN, new Color(255, 236, 200));
        }

        private static void riceBag(Graphics2D g) {
            shadow(g, 18, 64);
            Path2D p = new Path2D.Double();
            p.moveTo(27, 22);
            p.quadTo(50, 14, 73, 22);
            p.lineTo(80, 86);
            p.quadTo(50, 94, 20, 86);
            p.closePath();
            outline(g, p, new Color(236, 220, 184), new Color(190, 165, 120));
            g.setColor(new Color(150, 105, 60));
            g.fill(new RoundRectangle2D.Double(39, 10, 22, 9, 4, 4));
            g.setColor(Color.WHITE);
            g.fill(new RoundRectangle2D.Double(30, 42, 40, 30, 6, 6));
            centered(g, "BASMATI", 50, 55, 8, Font.BOLD, new Color(46, 125, 50));
            centered(g, "RICE  5 kg", 50, 66, 6, Font.PLAIN, new Color(120, 90, 50));
        }

        private static void teaBox(Graphics2D g) {
            shadow(g, 20, 60);
            Path2D top = new Path2D.Double();
            top.moveTo(22, 26);
            top.lineTo(34, 16);
            top.lineTo(84, 16);
            top.lineTo(72, 26);
            top.closePath();
            g.setColor(new Color(120, 190, 130));
            g.fill(top);
            Path2D side = new Path2D.Double();
            side.moveTo(72, 26);
            side.lineTo(84, 16);
            side.lineTo(84, 78);
            side.lineTo(72, 88);
            side.closePath();
            g.setColor(new Color(46, 120, 66));
            g.fill(side);
            g.setColor(new Color(66, 150, 88));
            g.fill(new Rectangle2D.Double(22, 26, 50, 62));
            Graphics2D leaf = (Graphics2D) g.create();
            leaf.rotate(Math.toRadians(-35), 47, 45);
            leaf.setColor(new Color(200, 240, 200));
            leaf.fill(new Ellipse2D.Double(37, 37, 20, 11));
            leaf.dispose();
            centered(g, "GREEN", 47, 68, 8, Font.BOLD, Color.WHITE);
            centered(g, "TEA", 47, 78, 8, Font.BOLD, Color.WHITE);
        }

        private static void almondJar(Graphics2D g) {
            shadow(g, 24, 52);
            g.setColor(new Color(140, 92, 52));
            g.fill(new RoundRectangle2D.Double(29, 10, 42, 14, 5, 5));
            outline(g, new RoundRectangle2D.Double(26, 22, 48, 68, 16, 16), new Color(245, 240, 230, 220),
                    new Color(190, 180, 165));
            int[][] nuts = {{34, 52}, {50, 48}, {40, 64}, {56, 62}, {34, 76}, {50, 78}, {58, 74}, {44, 40}};
            for (int i = 0; i < nuts.length; i++) {
                Graphics2D nut = (Graphics2D) g.create();
                nut.rotate(Math.toRadians(i * 40), nuts[i][0] + 5, nuts[i][1] + 3.5);
                nut.setColor(new Color(176, 112, 62));
                nut.fill(new Ellipse2D.Double(nuts[i][0], nuts[i][1], 11, 7));
                nut.dispose();
            }
            g.setColor(Color.WHITE);
            g.fill(new RoundRectangle2D.Double(32, 28, 36, 12, 4, 4));
            centered(g, "ALMONDS", 50, 37, 6, Font.BOLD, new Color(140, 92, 52));
        }
    }
}
