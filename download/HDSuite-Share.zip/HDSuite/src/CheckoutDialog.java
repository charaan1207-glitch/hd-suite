import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 * Three-step checkout, switched with a CardLayout:
 *   1. delivery details (validated, errors shown inline in red)
 *   2. payment processing animation
 *   3. order confirmed, with the receipt
 */
public class CheckoutDialog extends JDialog implements ActionListener {

    private static final long serialVersionUID = 1L;

    private static final String STEP_DETAILS = "details";
    private static final String STEP_PAYING = "paying";
    private static final String STEP_DONE = "done";

    private final Store store;
    private final ShoppingCart cart;
    private final CardLayout steps = new CardLayout();
    private final JPanel stepPanel = new JPanel(steps);

    private final JTextField nameField = new JTextField();
    private final JTextField mobileField = new JTextField();
    private final JTextArea addressArea = new JTextArea(3, 20);
    private final JTextField pinField = new JTextField();
    private final JLabel errorLabel = new JLabel(" ");
    private final FlatButton payButton;
    private final FlatButton backButton = new FlatButton("Back to Cart", Color.WHITE, new Color(55, 65, 81));

    private final JLabel payingLabel = new JLabel("", SwingConstants.CENTER);
    private final JLabel doneTitle = new JLabel("Order placed successfully!", SwingConstants.CENTER);
    private final JLabel doneSubtitle = new JLabel(" ", SwingConstants.CENTER);
    private final JTextArea receiptArea = new JTextArea();
    private final FlatButton continueButton = new FlatButton("Continue Shopping", UiUtil.SHOP_COLOR);

    private final Border normalBorder;
    private boolean orderPlaced;

    public CheckoutDialog(Frame owner, Store store, ShoppingCart cart) {
        super(owner, "Checkout", true);
        this.store = store;
        this.cart = cart;
        normalBorder = nameField.getBorder();
        payButton = new FlatButton(payText(), UiUtil.OK_GREEN);

        stepPanel.add(buildDetailsStep(), STEP_DETAILS);
        stepPanel.add(buildPayingStep(), STEP_PAYING);
        stepPanel.add(buildDoneStep(), STEP_DONE);
        setContentPane(stepPanel);

        nameField.setName("customerName");
        mobileField.setName("customerMobile");
        addressArea.setName("customerAddress");
        pinField.setName("customerPin");
        payButton.setName("payButton");
        backButton.setName("backButton");
        errorLabel.setName("checkoutError");
        receiptArea.setName("receipt");
        continueButton.setName("continueButton");

        payButton.addActionListener(this);
        backButton.addActionListener(this);
        continueButton.addActionListener(this);
        UiUtil.allowDigitsOnly(mobileField, 10);
        UiUtil.allowDigitsOnly(pinField, 6);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(760, 520);
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    /** True once the order has actually been placed. */
    public boolean isOrderPlaced() {
        return orderPlaced;
    }

    private String payText() {
        String amount = Money.format(cart.getGrandTotal());
        return ShoppingCart.PAY_COD.equals(cart.getPaymentMode()) ? "Place Order (" + amount + ")" : "Pay " + amount;
    }

    // ---------------- step 1: details ----------------

    private JPanel buildDetailsStep() {
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setOpaque(false);
        nameField.setPreferredSize(new Dimension(300, 32));
        mobileField.setPreferredSize(new Dimension(300, 32));
        pinField.setPreferredSize(new Dimension(300, 32));
        addField(form, "Full name", nameField);
        addField(form, "Mobile number (10 digits)", mobileField);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setFont(UiUtil.BASE_FONT);
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addField(form, "Delivery address", addressScroll);
        addField(form, "PIN code", pinField);

        errorLabel.setForeground(UiUtil.ERROR_RED);
        errorLabel.setFont(UiUtil.BOLD_FONT);

        JPanel left = new JPanel(new BorderLayout(0, 8));
        left.setOpaque(false);
        JLabel heading = new JLabel("<html><font color='#8a8f98' size='3'>CART &nbsp;&gt;&nbsp; "
                + "<font color='#d85c16'><b>DELIVERY</b></font> &nbsp;&gt;&nbsp; PAYMENT &nbsp;&gt;&nbsp; DONE</font>"
                + "<br><b style='font-size:15px'>Where should we deliver?</b></html>");
        left.add(heading, BorderLayout.NORTH);
        left.add(form, BorderLayout.CENTER);
        left.add(errorLabel, BorderLayout.SOUTH);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(backButton);
        buttons.add(payButton);

        JPanel content = new JPanel(new BorderLayout(18, 12));
        content.setBackground(Color.WHITE);
        content.setBorder(new EmptyBorder(18, 20, 16, 20));
        content.add(left, BorderLayout.CENTER);
        content.add(buildSummary(), BorderLayout.EAST);
        content.add(buttons, BorderLayout.SOUTH);
        return content;
    }

    private static void addField(JPanel form, String label, Component field) {
        JPanel row = new JPanel(new BorderLayout(0, 2));
        row.setOpaque(false);
        JLabel l = new JLabel(label);
        l.setForeground(new Color(90, 98, 110));
        row.add(l, BorderLayout.NORTH);
        row.add(field, BorderLayout.CENTER);
        row.setBorder(new EmptyBorder(0, 0, 10, 0));
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
        form.add(row);
    }

    private JPanel buildSummary() {
        JPanel summary = new JPanel();
        summary.setLayout(new BoxLayout(summary, BoxLayout.Y_AXIS));
        summary.setBackground(new Color(247, 248, 250));
        summary.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 230, 236)), new EmptyBorder(12, 14, 12, 14)));
        summary.setPreferredSize(new Dimension(290, 10));

        JLabel title = new JLabel("Order summary  (" + cart.getTotalQuantity() + " items)");
        title.setFont(new Font("Segoe UI", Font.BOLD, 15));
        add(summary, title);
        summary.add(javax.swing.Box.createVerticalStrut(8));
        int shown = 0;
        for (CartItem item : cart.getItems()) {
            if (shown++ == 4) {
                add(summary, new JLabel("+ " + (cart.getItems().size() - 4) + " more item(s)"));
                break;
            }
            JLabel line = new JLabel(item.getQuantity() + " x " + item.getProduct().getName(),
                    Art.product(item.getProduct().getId(), 30, 30), JLabel.LEFT);
            line.setIconTextGap(8);
            add(summary, line);
        }
        summary.add(javax.swing.Box.createVerticalStrut(10));
        add(summary, summaryLine("Subtotal", Money.format(cart.getSubtotal()), false));
        add(summary, summaryLine("Tax", Money.format(cart.getTax()), false));
        if (cart.getDiscount() > 0) {
            add(summary, summaryLine("Coupon " + cart.getCoupon().getCode(), "- " + Money.format(cart.getDiscount()), false));
        }
        add(summary, summaryLine("Delivery", cart.getDeliveryCharge() == 0 ? "FREE" : Money.format(cart.getDeliveryCharge()), false));
        if (cart.getOtherCharges() > 0) {
            add(summary, summaryLine("Gift wrap / COD", Money.format(cart.getOtherCharges()), false));
        }
        summary.add(javax.swing.Box.createVerticalStrut(6));
        add(summary, summaryLine("Total", Money.format(cart.getGrandTotal()), true));
        add(summary, summaryLine("Payment", cart.getPaymentMode(), false));
        return summary;
    }

    private static void add(JPanel panel, JComponent c) {
        c.setAlignmentX(LEFT_ALIGNMENT);
        panel.add(c);
    }

    private static JPanel summaryLine(String label, String value, boolean bold) {
        JPanel line = new JPanel(new BorderLayout());
        line.setOpaque(false);
        line.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
        JLabel l = new JLabel(label);
        JLabel v = new JLabel(value, SwingConstants.RIGHT);
        if (bold) {
            Font f = new Font("Segoe UI", Font.BOLD, 16);
            l.setFont(f);
            v.setFont(f);
            v.setForeground(UiUtil.SHOP_COLOR);
        }
        line.add(l, BorderLayout.WEST);
        line.add(v, BorderLayout.EAST);
        return line;
    }

    // ---------------- step 2: paying ----------------

    private JPanel buildPayingStep() {
        payingLabel.setFont(new Font("Segoe UI", Font.BOLD, 17));
        JProgressBar bar = new JProgressBar();
        bar.setIndeterminate(true);
        bar.setPreferredSize(new Dimension(420, 10));
        JLabel note = new JLabel("Please do not close this window", SwingConstants.CENTER);
        note.setForeground(Color.GRAY);

        JPanel column = new JPanel(new BorderLayout(0, 16));
        column.setOpaque(false);
        column.add(payingLabel, BorderLayout.NORTH);
        column.add(bar, BorderLayout.CENTER);
        column.add(note, BorderLayout.SOUTH);

        JPanel panel = new JPanel(new java.awt.GridBagLayout()); // centres the column in the dialog
        panel.setBackground(Color.WHITE);
        panel.add(column);
        return panel;
    }

    // ---------------- step 3: done ----------------

    private JPanel buildDoneStep() {
        JPanel top = new JPanel(new BorderLayout(0, 6));
        top.setOpaque(false);
        top.add(new JLabel(Art.check(64), SwingConstants.CENTER), BorderLayout.NORTH);
        doneTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        doneTitle.setForeground(UiUtil.OK_GREEN);
        top.add(doneTitle, BorderLayout.CENTER);
        doneSubtitle.setForeground(new Color(90, 98, 110));
        top.add(doneSubtitle, BorderLayout.SOUTH);

        receiptArea.setEditable(false);
        receiptArea.setFont(UiUtil.monoFont(12));
        receiptArea.setMargin(new java.awt.Insets(6, 10, 6, 10));
        JScrollPane scroll = new JScrollPane(receiptArea);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setOpaque(false);
        bottom.add(continueButton);

        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(14, 60, 12, 60));
        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    // ---------------- events ----------------

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == payButton) {
            submit();
        } else if (e.getSource() == backButton || e.getSource() == continueButton) {
            dispose();
        }
    }

    private void submit() {
        nameField.setBorder(normalBorder);
        mobileField.setBorder(normalBorder);
        pinField.setBorder(normalBorder);
        addressArea.setBorder(null);
        final String name;
        final String mobile;
        final String address;
        final String pin;
        try {
            name = Validator.requireName(nameField.getText(), "Full name");
            mobile = Validator.requireMobile(mobileField.getText());
            address = Validator.requireText(addressArea.getText(), "Delivery address", 10);
            pin = Validator.requirePincode(pinField.getText());
        } catch (ValidationException ex) {
            showError(ex.getMessage());
            return;
        }
        errorLabel.setText(" ");
        payingLabel.setText(ShoppingCart.PAY_COD.equals(cart.getPaymentMode())
                ? "Confirming your Cash on Delivery order..."
                : "Processing " + cart.getPaymentMode() + " payment of " + Money.format(cart.getGrandTotal()) + "...");
        steps.show(stepPanel, STEP_PAYING);

        // Simulated payment gateway delay, then place the order
        Timer timer = new Timer(1600, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String receipt = store.placeOrder(cart, name, mobile, address, pin);
                    orderPlaced = true;
                    doneSubtitle.setText("Order ID " + store.getLastOrderId() + "   -   arriving by "
                            + LocalDate.now().plusDays(3).format(DateTimeFormatter.ofPattern("EEEE, dd MMM", Locale.ENGLISH)));
                    receiptArea.setText(receipt);
                    receiptArea.setCaretPosition(0);
                    steps.show(stepPanel, STEP_DONE);
                    setTitle("Order Confirmed");
                } catch (ValidationException ex) {
                    steps.show(stepPanel, STEP_DETAILS);
                    showError(ex.getMessage());
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    /** Shows the message in red under the form and outlines the field that needs fixing. */
    private void showError(String message) {
        errorLabel.setText("<html>" + message + "</html>");
        JComponent bad = fieldFor(message);
        if (bad != null) {
            bad.setBorder(BorderFactory.createLineBorder(UiUtil.ERROR_RED, 2));
            bad.requestFocusInWindow();
        }
        java.awt.Toolkit.getDefaultToolkit().beep();
    }

    private JComponent fieldFor(String message) {
        if (message.startsWith("Full name")) {
            return nameField;
        }
        if (message.startsWith("Mobile")) {
            return mobileField;
        }
        if (message.startsWith("PIN")) {
            return pinField;
        }
        if (message.startsWith("Delivery address")) {
            return addressArea;
        }
        return null;
    }
}
