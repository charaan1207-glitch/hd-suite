import java.time.LocalDate;

/** Sleeper class (SL): cheapest, no GST. */
public class SleeperTicket extends Ticket {

    public static final int SEATS = 8;

    public SleeperTicket(String pnr, Passenger passenger, Train train, LocalDate journeyDate,
                         String berthPreference, boolean meals, boolean insurance) {
        super(pnr, passenger, train, journeyDate, berthPreference, meals, insurance);
    }

    @Override
    public String getClassCode() {
        return "SL";
    }

    @Override
    public String getClassName() {
        return "Sleeper";
    }

    @Override
    public int getTotalSeats() {
        return SEATS;
    }

    @Override
    protected double getRatePerKm() {
        return 0.60;
    }

    @Override
    protected double getReservationCharge() {
        return 20.0;
    }

    @Override
    protected double getGstPercent() {
        return 0.0;
    }

    @Override
    protected String getCoachCode() {
        return "S1";
    }

    @Override
    public double getCancellationCharge() {
        return 120.0;
    }
}
