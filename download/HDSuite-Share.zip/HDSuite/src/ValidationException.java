/**
 * Thrown when the user enters something the application cannot accept:
 * an empty field, a wrong format, a value out of range, or a broken rule
 * (for example "From" and "To" stations are the same).
 *
 * It is a checked exception, so every caller is forced to handle it.
 */
public class ValidationException extends Exception {

    private static final long serialVersionUID = 1L;

    public ValidationException(String message) {
        super(message);
    }
}
