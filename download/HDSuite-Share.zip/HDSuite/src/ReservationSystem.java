import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

/**
 * The "back office" of the railway module: holds the trains and all bookings,
 * gives out PNR numbers, allots berths, runs the waiting list and handles
 * cancellations. It has no GUI code, so it can be tested on its own.
 */
public class ReservationSystem {

    public static final int MAX_WAITING_LIST = 5;
    public static final int ADVANCE_BOOKING_DAYS = 120;
    public static final double WAITLIST_CANCELLATION_CHARGE = 60.0;

    private final List<Train> trains = new ArrayList<Train>();
    private final List<Ticket> bookings = new ArrayList<Ticket>();
    private long nextPnr = 4521873601L;

    public ReservationSystem() {
        loadTrains();
    }

    /** Demo timetable (timings and distances are approximate). */
    private void loadTrains() {
        trains.add(new Train("12607", "Lalbagh Express", "Chennai Central", "KSR Bengaluru", "15:30", "21:40", 362));
        trains.add(new Train("12608", "Lalbagh Express", "KSR Bengaluru", "Chennai Central", "06:30", "12:30", 362));
        trains.add(new Train("12639", "Brindavan Express", "Chennai Central", "KSR Bengaluru", "07:50", "14:05", 362));
        trains.add(new Train("12640", "Brindavan Express", "KSR Bengaluru", "Chennai Central", "15:00", "21:05", 362));
        trains.add(new Train("12621", "Tamil Nadu Express", "Chennai Central", "New Delhi", "22:00", "06:30 (+2)", 2182));
        trains.add(new Train("12622", "Tamil Nadu Express", "New Delhi", "Chennai Central", "22:30", "07:10 (+2)", 2182));
        trains.add(new Train("12163", "Chennai Express", "Mumbai CSMT", "Chennai Central", "20:30", "19:40 (+1)", 1279));
        trains.add(new Train("12164", "Chennai Express", "Chennai Central", "Mumbai CSMT", "06:50", "05:00 (+1)", 1279));
        trains.add(new Train("12603", "Hyderabad Express", "Chennai Central", "Hyderabad", "16:45", "05:20 (+1)", 794));
        trains.add(new Train("12604", "Hyderabad Express", "Hyderabad", "Chennai Central", "16:30", "05:00 (+1)", 794));
        trains.add(new Train("12839", "Howrah Mail", "Howrah", "Chennai Central", "23:55", "04:00 (+2)", 1662));
        trains.add(new Train("12840", "Howrah Mail", "Chennai Central", "Howrah", "19:00", "23:25 (+1)", 1662));
        trains.add(new Train("12627", "Karnataka Express", "KSR Bengaluru", "New Delhi", "19:20", "10:40 (+2)", 2365));
        trains.add(new Train("12628", "Karnataka Express", "New Delhi", "KSR Bengaluru", "20:20", "13:10 (+2)", 2365));
        trains.add(new Train("12701", "Hussainsagar Express", "Mumbai CSMT", "Hyderabad", "21:50", "12:40 (+1)", 711));
        trains.add(new Train("12702", "Hussainsagar Express", "Hyderabad", "Mumbai CSMT", "14:45", "05:25 (+1)", 711));
    }

    /** All station names, sorted alphabetically. */
    public String[] getStations() {
        TreeSet<String> stations = new TreeSet<String>();
        for (Train train : trains) {
            stations.add(train.getSource());
            stations.add(train.getDestination());
        }
        return stations.toArray(new String[0]);
    }

    public List<Train> findTrains(String from, String to) {
        List<Train> result = new ArrayList<Train>();
        for (Train train : trains) {
            if (train.getSource().equals(from) && train.getDestination().equals(to)) {
                result.add(train);
            }
        }
        return result;
    }

    public static int seatsInClass(String classCode) {
        if ("SL".equals(classCode)) {
            return SleeperTicket.SEATS;
        }
        if ("3A".equals(classCode)) {
            return AcThreeTierTicket.SEATS;
        }
        if ("2A".equals(classCode)) {
            return AcTwoTierTicket.SEATS;
        }
        throw new IllegalArgumentException("Unknown class: " + classCode);
    }

    /** Factory: creates the right Ticket subclass for the chosen class code. */
    public Ticket createTicket(String pnr, String classCode, Passenger passenger, Train train, LocalDate date,
                               String berth, boolean meals, boolean insurance) {
        if ("SL".equals(classCode)) {
            return new SleeperTicket(pnr, passenger, train, date, berth, meals, insurance);
        }
        if ("3A".equals(classCode)) {
            return new AcThreeTierTicket(pnr, passenger, train, date, berth, meals, insurance);
        }
        if ("2A".equals(classCode)) {
            return new AcTwoTierTicket(pnr, passenger, train, date, berth, meals, insurance);
        }
        throw new IllegalArgumentException("Unknown class: " + classCode);
    }

    /** A ticket that is only used to show the fare - it is not saved. */
    public Ticket quote(String classCode, Passenger passenger, Train train, LocalDate date,
                        String berth, boolean meals, boolean insurance) {
        return createTicket("(not booked yet)", classCode, passenger, train, date, berth, meals, insurance);
    }

    public int getAvailableSeats(Train train, String classCode, LocalDate date) {
        return seatsInClass(classCode) - count(train, classCode, date, Ticket.Status.CONFIRMED);
    }

    public int getWaitingCount(Train train, String classCode, LocalDate date) {
        return count(train, classCode, date, Ticket.Status.WAITING);
    }

    public Ticket book(String classCode, Passenger passenger, Train train, LocalDate date,
                       String berth, boolean meals, boolean insurance) throws ValidationException {
        for (Ticket existing : bookings) {
            if (existing.getStatus() != Ticket.Status.CANCELLED
                    && existing.getTrain() == train
                    && existing.getJourneyDate().equals(date)
                    && existing.getPassenger().getName().equalsIgnoreCase(passenger.getName())
                    && existing.getPassenger().getMobile().equals(passenger.getMobile())) {
                throw new ValidationException(passenger.getName() + " already has a booking on this train and date (PNR "
                        + existing.getPnr() + ").");
            }
        }

        Ticket ticket = createTicket(String.valueOf(nextPnr), classCode, passenger, train, date, berth, meals, insurance);
        int seat = pickSeat(ticket);
        if (seat > 0) {
            ticket.confirm(seat);
        } else {
            int waiting = getWaitingCount(train, classCode, date);
            if (waiting >= MAX_WAITING_LIST) {
                throw new ValidationException("REGRET: " + ticket.getClassName() + " on train " + train.getNumber()
                        + " is full and the waiting list is closed. Please try another class, train or date.");
            }
            ticket.waitlist(waiting + 1);
        }
        nextPnr++;
        bookings.add(ticket);
        return ticket;
    }

    public Ticket findByPnr(String pnr) {
        for (Ticket ticket : bookings) {
            if (ticket.getPnr().equals(pnr)) {
                return ticket;
            }
        }
        return null;
    }

    /** Returns the ticket for this PNR, or explains why it cannot be cancelled. */
    public Ticket requireActiveTicket(String pnrInput) throws ValidationException {
        String pnr = pnrInput == null ? "" : pnrInput.trim();
        if (pnr.isEmpty()) {
            throw new ValidationException("Please enter a PNR number.");
        }
        if (!pnr.matches("[0-9]{10}")) {
            throw new ValidationException("PNR number must be exactly 10 digits.");
        }
        Ticket ticket = findByPnr(pnr);
        if (ticket == null) {
            throw new ValidationException("No booking found with PNR " + pnr + ".");
        }
        if (ticket.getStatus() == Ticket.Status.CANCELLED) {
            throw new ValidationException("PNR " + pnr + " is already cancelled.");
        }
        return ticket;
    }

    /** Cancels a ticket, works out the refund and moves the waiting list up. */
    public Ticket cancel(String pnrInput) throws ValidationException {
        Ticket ticket = requireActiveTicket(pnrInput);
        boolean wasConfirmed = ticket.getStatus() == Ticket.Status.CONFIRMED;
        int freedSeat = ticket.getSeatNumber();
        double charge = wasConfirmed ? ticket.getCancellationCharge() : WAITLIST_CANCELLATION_CHARGE;
        ticket.cancel(Money.round(Math.max(0, ticket.getTotalFare() - charge)));

        List<Ticket> waiting = waitingList(ticket.getTrain(), ticket.getClassCode(), ticket.getJourneyDate());
        if (wasConfirmed && !waiting.isEmpty()) {
            waiting.remove(0).confirm(freedSeat);   // WL 1 gets the freed berth
        }
        for (int i = 0; i < waiting.size(); i++) {
            waiting.get(i).waitlist(i + 1);         // everyone else moves up
        }
        return ticket;
    }

    public List<Ticket> getBookings() {
        return Collections.unmodifiableList(bookings);
    }

    // ---------- helpers ----------

    private boolean sameJourney(Ticket t, Train train, String classCode, LocalDate date) {
        return t.getTrain() == train && t.getClassCode().equals(classCode) && t.getJourneyDate().equals(date);
    }

    private int count(Train train, String classCode, LocalDate date, Ticket.Status status) {
        int n = 0;
        for (Ticket t : bookings) {
            if (t.getStatus() == status && sameJourney(t, train, classCode, date)) {
                n++;
            }
        }
        return n;
    }

    /** Waiting tickets for one journey, in waiting-list order. */
    private List<Ticket> waitingList(Train train, String classCode, LocalDate date) {
        List<Ticket> list = new ArrayList<Ticket>();
        for (int position = 1; position <= MAX_WAITING_LIST; position++) {
            for (Ticket t : bookings) {
                if (t.getStatus() == Ticket.Status.WAITING && t.getWaitingNumber() == position
                        && sameJourney(t, train, classCode, date)) {
                    list.add(t);
                }
            }
        }
        return list;
    }

    /**
     * Picks a free berth, honouring the passenger's preference when possible.
     * Senior citizens with no preference are given a lower berth first.
     * Returns 0 when the class is full.
     */
    private int pickSeat(Ticket ticket) {
        int total = ticket.getTotalSeats();
        boolean[] taken = new boolean[total + 1];
        for (Ticket t : bookings) {
            if (t.getStatus() == Ticket.Status.CONFIRMED
                    && sameJourney(t, ticket.getTrain(), ticket.getClassCode(), ticket.getJourneyDate())) {
                taken[t.getSeatNumber()] = true;
            }
        }
        String wanted = berthCode(ticket.getBerthPreference());
        if (wanted == null && ticket.getPassenger().isSeniorCitizen()) {
            wanted = "LB";
        }
        if (wanted != null) {
            for (int seat = 1; seat <= total; seat++) {
                if (!taken[seat] && ticket.getBerthType(seat).equals(wanted)) {
                    return seat;
                }
            }
        }
        for (int seat = 1; seat <= total; seat++) {
            if (!taken[seat]) {
                return seat;
            }
        }
        return 0;
    }

    private static String berthCode(String preference) {
        if ("Lower".equals(preference)) {
            return "LB";
        }
        if ("Middle".equals(preference)) {
            return "MB";
        }
        if ("Upper".equals(preference)) {
            return "UB";
        }
        if ("Side Lower".equals(preference)) {
            return "SL";
        }
        if ("Side Upper".equals(preference)) {
            return "SU";
        }
        return null;
    }
}
