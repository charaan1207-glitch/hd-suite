/** Clothes: tax depends on the price (5% up to Rs 1000, 12% above - a simplified demo slab). */
public class Clothing extends Product {

    private final String sizes;
    private final String material;

    public Clothing(String id, String name, double price, int stock, String sizes, String material) {
        super(id, name, price, stock);
        this.sizes = sizes;
        this.material = material;
    }

    @Override
    public String getCategory() {
        return "Clothing";
    }

    @Override
    public double getTaxPercent() {
        return getPrice() <= 1000 ? 5.0 : 12.0;
    }

    @Override
    public String getSpecialInfo() {
        return "Sizes      : " + sizes + "\n"
                + "Material   : " + material;
    }
}
