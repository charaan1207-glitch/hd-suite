/** Packaged groceries: 5% tax, sold by pack size. */
public class Grocery extends Product {

    private final String packSize;

    public Grocery(String id, String name, double price, int stock, String packSize) {
        super(id, name, price, stock);
        this.packSize = packSize;
    }

    @Override
    public String getCategory() {
        return "Grocery";
    }

    @Override
    public double getTaxPercent() {
        return 5.0;
    }

    @Override
    public String getSpecialInfo() {
        return "Pack size  : " + packSize;
    }
}
