/** A train running between two stations. All fields are private (encapsulation). */
public class Train {

    private final String number;
    private final String name;
    private final String source;
    private final String destination;
    private final String departure;
    private final String arrival;
    private final int distanceKm;

    public Train(String number, String name, String source, String destination,
                 String departure, String arrival, int distanceKm) {
        this.number = number;
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.departure = departure;
        this.arrival = arrival;
        this.distanceKm = distanceKm;
    }

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getDeparture() {
        return departure;
    }

    public String getArrival() {
        return arrival;
    }

    public int getDistanceKm() {
        return distanceKm;
    }

    /** Shown in the train combo box, e.g. "12607 - Lalbagh Express (15:30)". */
    @Override
    public String toString() {
        return number + " - " + name + " (" + departure + ")";
    }
}
