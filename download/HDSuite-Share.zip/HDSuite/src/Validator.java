import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/**
 * Reusable input checks shared by both modules.
 * Each method returns the cleaned value, or throws a ValidationException
 * whose message tells the user exactly what to fix.
 */
public final class Validator {

    /** dd-MM-yyyy, strict: 31-02-2026 is rejected instead of rolling over. */
    public static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT);

    private Validator() {
    }

    public static String requireText(String raw, String field, int minLength) throws ValidationException {
        String text = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (text.isEmpty()) {
            throw new ValidationException(field + " is required.");
        }
        if (text.length() < minLength) {
            throw new ValidationException(field + " must be at least " + minLength + " characters long.");
        }
        return text;
    }

    public static String requireName(String raw, String field) throws ValidationException {
        String name = requireText(raw, field, 2);
        if (name.length() > 40) {
            throw new ValidationException(field + " cannot be longer than 40 characters.");
        }
        if (!name.matches("[A-Za-z][A-Za-z .']*")) {
            throw new ValidationException(field + " can contain only letters, spaces, dots and apostrophes.");
        }
        return name;
    }

    public static int parseIntInRange(String raw, String field, int min, int max) throws ValidationException {
        String text = requireText(raw, field, 1);
        int value;
        try {
            value = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new ValidationException(field + " must be a valid whole number (you entered \"" + text + "\").");
        }
        if (value < min || value > max) {
            throw new ValidationException(field + " must be between " + min + " and " + max + ".");
        }
        return value;
    }

    public static String requireMobile(String raw) throws ValidationException {
        String mobile = requireText(raw, "Mobile number", 1);
        if (!mobile.matches("[6-9][0-9]{9}")) {
            throw new ValidationException("Mobile number must be exactly 10 digits and start with 6, 7, 8 or 9.");
        }
        return mobile;
    }

    public static String requirePincode(String raw) throws ValidationException {
        String pin = requireText(raw, "PIN code", 1);
        if (!pin.matches("[1-9][0-9]{5}")) {
            throw new ValidationException("PIN code must be exactly 6 digits and cannot start with 0.");
        }
        return pin;
    }

    /** Parses a dd-MM-yyyy date that must lie between today and today + maxDaysAhead. */
    public static LocalDate parseFutureDate(String raw, String field, LocalDate today, int maxDaysAhead)
            throws ValidationException {
        String text = requireText(raw, field, 1);
        LocalDate date;
        try {
            date = LocalDate.parse(text, DATE_FORMAT);
        } catch (DateTimeParseException e) {
            throw new ValidationException(field + " \"" + text + "\" is not a valid date. Use dd-MM-yyyy, for example "
                    + today.plusDays(1).format(DATE_FORMAT) + ".");
        }
        if (date.isBefore(today)) {
            throw new ValidationException(field + " cannot be in the past.");
        }
        LocalDate lastDate = today.plusDays(maxDaysAhead);
        if (date.isAfter(lastDate)) {
            throw new ValidationException("Bookings open only " + maxDaysAhead + " days in advance (up to "
                    + lastDate.format(DATE_FORMAT) + ").");
        }
        return date;
    }
}
