import java.util.Locale;

/**
 * Base class of every item sold in the shop.
 * Each category is a subclass that decides its own tax rate and extra details
 * (polymorphism), while the common fields stay private here (encapsulation).
 */
public abstract class Product {

    private final String id;
    private final String name;
    private final double price;
    private int stock;

    // Shop-listing details shown on the product card
    private double mrp;
    private double rating;
    private int reviews;
    private String badge;

    protected Product(String id, String name, double price, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.mrp = price;
    }

    /** Sets the listing details: maximum retail price, star rating (0-5), review count and an optional badge. */
    public Product withListing(double mrp, double rating, int reviews, String badge) {
        this.mrp = Math.max(mrp, price);
        this.rating = Math.max(0, Math.min(5, rating));
        this.reviews = reviews;
        this.badge = badge;
        return this;
    }

    public double getMrp() {
        return mrp;
    }

    /** Percentage saved against the MRP, e.g. 50 for "50% off". */
    public int getDiscountPercent() {
        return (int) Math.round((mrp - price) * 100.0 / mrp);
    }

    public double getRating() {
        return rating;
    }

    public int getReviews() {
        return reviews;
    }

    public String getBadge() {
        return badge;
    }

    public abstract String getCategory();

    /** Tax in percent. Demo rates, set per category. */
    public abstract double getTaxPercent();

    /** Category-specific lines for the product details dialog. */
    public abstract String getSpecialInfo();

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    void reduceStock(int quantity) throws ValidationException {
        if (quantity > stock) {
            throw new ValidationException("Only " + stock + " unit(s) of " + name + " are left in stock.");
        }
        stock -= quantity;
    }

    public String getDetails() {
        return "Product ID : " + id + "\n"
                + "Name       : " + name + "\n"
                + "Category   : " + getCategory() + "\n"
                + "Price      : " + Money.format(price) + "\n"
                + "Tax        : " + String.format(Locale.ENGLISH, "%.0f%%", getTaxPercent()) + "\n"
                + "In stock   : " + stock + "\n"
                + getSpecialInfo();
    }

    @Override
    public String toString() {
        return name;
    }
}
