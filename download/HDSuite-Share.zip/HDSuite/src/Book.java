/** Printed books: no tax. */
public class Book extends Product {

    private final String author;

    public Book(String id, String name, double price, int stock, String author) {
        super(id, name, price, stock);
        this.author = author;
    }

    @Override
    public String getCategory() {
        return "Books";
    }

    @Override
    public double getTaxPercent() {
        return 0.0;
    }

    @Override
    public String getSpecialInfo() {
        return "Author     : " + author + "\n"
                + "Format     : Paperback";
    }
}
