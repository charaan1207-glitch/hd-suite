import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.Locale;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * One product tile in the shop grid: picture, badges, name, rating, price,
 * stock and an "Add to Cart" button. Clicking the picture opens its details.
 *
 * The card does not change the cart itself; it sends ActionEvents
 * ("ADD" and "DETAILS") to the listener it is given - the delegation event model.
 */
public class ProductCard extends JPanel {

    private static final long serialVersionUID = 1L;

    public static final String ADD = "ADD";
    public static final String DETAILS = "DETAILS";

    private final Product product;
    private final JComboBox<Integer> quantityCombo = new JComboBox<Integer>();
    private boolean hover;

    public ProductCard(final Product product, final ActionListener listener) {
        super(new BorderLayout(0, 8));
        this.product = product;
        setOpaque(false);
        setBorder(new EmptyBorder(12, 12, 12, 12));
        setPreferredSize(new Dimension(250, 368));
        putClientProperty("product", product);
        setName("card-" + product.getId());

        final ImagePanel image = new ImagePanel();
        image.setToolTipText("Click to see details of " + product.getName());
        add(image, BorderLayout.NORTH);
        add(buildInfo(), BorderLayout.CENTER);
        add(buildActions(listener), BorderLayout.SOUTH);

        // MouseAdapter: lift the card on hover, open details when the picture is clicked
        MouseAdapter mouse = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (getMousePosition(true) == null) {
                    hover = false;
                    repaint();
                }
            }
        };
        addMouseListener(mouse);
        image.addMouseListener(mouse);
        image.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                listener.actionPerformed(new ActionEvent(ProductCard.this, ActionEvent.ACTION_PERFORMED, DETAILS));
            }
        });
    }

    public Product getProduct() {
        return product;
    }

    private JPanel buildInfo() {
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel category = new JLabel(product.getCategory().toUpperCase(Locale.ENGLISH));
        category.setFont(new Font("Segoe UI", Font.BOLD, 11));
        category.setForeground(new Color(120, 128, 140));

        JLabel name = new JLabel("<html><div style='width:205px'>" + product.getName() + "</div></html>");
        name.setFont(new Font("Segoe UI", Font.BOLD, 14));
        name.setForeground(new Color(33, 37, 41));

        JLabel rating = new JLabel(String.format(Locale.ENGLISH, "%.1f  (%,d)", product.getRating(), product.getReviews()),
                Art.stars(product.getRating(), 13), JLabel.LEFT);
        rating.setIconTextGap(6);
        rating.setForeground(new Color(100, 108, 120));

        StringBuilder price = new StringBuilder("<html><span style='font-size:15px'><b>")
                .append(Money.format(product.getPrice())).append("</b></span>");
        if (product.getDiscountPercent() > 0) {
            price.append("&nbsp; <s><font color='#8a8f98'>").append(Money.format(product.getMrp()))
                    .append("</font></s>");
        }
        price.append("</html>");
        JLabel priceLabel = new JLabel(price.toString());

        JLabel stock = new JLabel();
        stock.setFont(new Font("Segoe UI", Font.BOLD, 12));
        if (product.getStock() == 0) {
            stock.setText("Out of stock");
            stock.setForeground(UiUtil.ERROR_RED);
        } else if (product.getStock() <= 5) {
            stock.setText("Hurry, only " + product.getStock() + " left!");
            stock.setForeground(UiUtil.WARN_ORANGE);
        } else {
            stock.setText("In stock  -  " + taxText());
            stock.setForeground(UiUtil.OK_GREEN);
        }

        for (JLabel label : new JLabel[] {category, name, rating, priceLabel, stock}) {
            label.setAlignmentX(LEFT_ALIGNMENT);
            label.setBorder(new EmptyBorder(1, 0, 3, 0));
            info.add(label);
        }
        return info;
    }

    private String taxText() {
        return product.getTaxPercent() == 0 ? "no tax"
                : String.format(Locale.ENGLISH, "+%.0f%% tax", product.getTaxPercent());
    }

    private JPanel buildActions(ActionListener listener) {
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        actions.setOpaque(false);
        int max = Math.min(ShoppingCart.MAX_QUANTITY_PER_ADD, Math.max(product.getStock(), 1));
        for (int i = 1; i <= max; i++) {
            quantityCombo.addItem(i);
        }
        quantityCombo.setToolTipText("Quantity");
        quantityCombo.setPreferredSize(new Dimension(58, 34));
        quantityCombo.setName("qty-" + product.getId());

        FlatButton add = new FlatButton(product.getStock() == 0 ? "Out of Stock" : "Add to Cart", UiUtil.SHOP_COLOR);
        add.setPreferredSize(new Dimension(160, 34));
        add.setActionCommand(ADD);
        add.setName("add-" + product.getId());
        add.putClientProperty("product", product);
        add.putClientProperty("quantity", quantityCombo);
        add.addActionListener(listener);
        if (product.getStock() == 0) {
            add.setEnabled(false);
            quantityCombo.setEnabled(false);
        }
        actions.add(quantityCombo);
        actions.add(javax.swing.Box.createHorizontalStrut(8));
        actions.add(add);
        return actions;
    }

    /** White rounded card with a soft shadow; orange outline on hover. */
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = Art.smooth(g);
        int w = getWidth();
        int h = getHeight();
        g2.setColor(new Color(0, 0, 0, hover ? 34 : 16));
        g2.fill(new RoundRectangle2D.Double(2, hover ? 5 : 3, w - 4, h - 5, 16, 16));
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Double(0, 0, w - 3, h - 5, 16, 16));
        g2.setColor(hover ? UiUtil.SHOP_COLOR : new Color(226, 230, 236));
        g2.draw(new RoundRectangle2D.Double(0, 0, w - 3, h - 5, 16, 16));
        g2.dispose();
        super.paintComponent(g);
    }

    /** The product picture with "Bestseller" / "-50%" / "Sold out" labels drawn on top. */
    private final class ImagePanel extends JPanel {
        private static final long serialVersionUID = 1L;
        private final Icon picture = Art.product(product.getId(), 226, 150);

        ImagePanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(226, 150));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            int x = (getWidth() - picture.getIconWidth()) / 2;
            picture.paintIcon(this, g, x, 0);
            Graphics2D g2 = Art.smooth(g);
            if (product.getBadge() != null) {
                pill(g2, product.getBadge(), x + 8, 8, new Color(33, 37, 41), false);
            }
            if (product.getDiscountPercent() > 0) {
                pill(g2, "-" + product.getDiscountPercent() + "%", x + picture.getIconWidth() - 8, 8,
                        new Color(46, 125, 50), true);
            }
            if (product.getStock() == 0) {
                g2.setColor(new Color(255, 255, 255, 170));
                g2.fill(new RoundRectangle2D.Double(x, 0, picture.getIconWidth(), picture.getIconHeight(), 20, 20));
                pill(g2, "SOLD OUT", x + picture.getIconWidth() / 2 + 34, 64, UiUtil.ERROR_RED, true);
            }
            g2.dispose();
        }

        private void pill(Graphics2D g2, String text, int x, int y, Color color, boolean alignRight) {
            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            FontMetrics fm = g2.getFontMetrics();
            int w = fm.stringWidth(text) + 14;
            int left = alignRight ? x - w : x;
            g2.setColor(color);
            g2.fill(new RoundRectangle2D.Double(left, y, w, 20, 20, 20));
            g2.setColor(Color.WHITE);
            g2.drawString(text, left + 7, y + 14);
        }
    }
}
