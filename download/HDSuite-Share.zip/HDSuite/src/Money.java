import java.util.Locale;

/** Small helper for rounding and printing rupee amounts. */
public final class Money {

    private Money() {
    }

    /** Rounds to 2 decimal places (paise). */
    public static double round(double amount) {
        return Math.round(amount * 100.0) / 100.0;
    }

    /** Formats an amount as "Rs. 1,234.50". */
    public static String format(double amount) {
        return String.format(Locale.ENGLISH, "Rs. %,.2f", amount);
    }

    /** Formats an amount as "1234.50" (used inside tables and receipts). */
    public static String plain(double amount) {
        return String.format(Locale.ENGLISH, "%.2f", amount);
    }
}
