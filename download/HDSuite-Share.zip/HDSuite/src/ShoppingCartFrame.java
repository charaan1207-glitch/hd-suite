import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

/**
 * Online Shopping Cart window - laid out like a real shopping site:
 * a top bar with search and cart badge, category chips, a grid of product
 * cards, and a cart sidebar with quantity steppers, coupon, payment and totals.
 *
 * Event handling (delegation event model):
 *   - ActionListener (this class): every button, menu item, product card and cart row
 *   - ItemListener   (this class): category chips, sort combo, gift-wrap checkbox, payment radio buttons
 *   - KeyAdapter: live search while typing
 *   - MouseAdapter: card hover and picture click (inside ProductCard), FlatButton hover
 */
public class ShoppingCartFrame extends JFrame implements ActionListener, ItemListener {

    private static final long serialVersionUID = 1L;

    private static final String[] SORT_OPTIONS =
        {"Relevance", "Price: Low to High", "Price: High to Low", "Customer Rating", "Biggest Discount"};

    private final Store store;
    private final ShoppingCart cart;

    // ----- top bar -----
    private final JTextField searchField = new HintTextField("Search for products, brands and more");
    private final FlatButton searchButton = new FlatButton("Search", new Color(255, 196, 0), new Color(33, 37, 41));
    private final JLabel cartBadge = new JLabel();

    // ----- filters + grid -----
    private final List<JToggleButton> categoryChips = new ArrayList<JToggleButton>();
    private final JComboBox<String> sortCombo = new JComboBox<String>(SORT_OPTIONS);
    private final JLabel resultsLabel = new JLabel();
    private final JPanel gridPanel = new JPanel(new GridLayout(0, 3, 16, 16));

    // ----- cart sidebar -----
    private final JLabel cartTitle = new JLabel();
    private final JPanel itemsPanel = new JPanel();
    private final JProgressBar deliveryBar = new JProgressBar(0, (int) ShoppingCart.FREE_DELIVERY_ABOVE);
    private final JLabel deliveryLabel = new JLabel(" ");
    private final JTextField couponField = new HintTextField("Coupon code");
    private final FlatButton applyCouponButton = new FlatButton("Apply", new Color(55, 65, 81));
    private final JLabel couponLabel = new JLabel(" ");
    private final JCheckBox giftWrapBox = new JCheckBox("Gift wrap this order (+Rs 50)");
    private final JRadioButton upiRadio = new JRadioButton("UPI", true);
    private final JRadioButton cardRadio = new JRadioButton("Card");
    private final JRadioButton codRadio = new JRadioButton("COD (+Rs 40)");
    private final JLabel subtotalValue = valueLabel();
    private final JLabel taxValue = valueLabel();
    private final JLabel discountValue = valueLabel();
    private final JLabel deliveryValue = valueLabel();
    private final JLabel otherValue = valueLabel();
    private final JLabel totalValue = valueLabel();
    private final FlatButton checkoutButton = new FlatButton("Proceed to Checkout", UiUtil.SHOP_COLOR);

    // ----- menu -----
    private final JMenuItem checkoutItem = new JMenuItem("Checkout...");
    private final JMenuItem emptyItem = new JMenuItem("Empty Cart");
    private final JMenuItem closeItem = new JMenuItem("Close Window");
    private final JMenuItem couponsItem = new JMenuItem("Available Coupons");
    private final JMenuItem aboutItem = new JMenuItem("About");

    // ----- toast message -----
    private final JLabel toast = new JLabel(" ", SwingConstants.CENTER);
    private final Timer toastTimer;

    public ShoppingCartFrame(Store store, ShoppingCart cart) {
        super("HD Cart - Online Shopping Cart");
        this.store = store;
        this.cart = cart;

        setJMenuBar(buildMenuBar());
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiUtil.PAGE_BG);
        JPanel north = new JPanel(new BorderLayout());
        north.add(buildTopBar(), BorderLayout.NORTH);
        north.add(buildFilterBar(), BorderLayout.SOUTH);
        root.add(north, BorderLayout.NORTH);
        root.add(buildGrid(), BorderLayout.CENTER);
        root.add(buildCartSidebar(), BorderLayout.EAST);

        toast.setOpaque(true);
        toast.setFont(UiUtil.BOLD_FONT);
        toast.setForeground(Color.WHITE);
        toast.setBorder(new EmptyBorder(7, 12, 7, 12));
        toast.setVisible(false);
        toast.setName("toast");
        root.add(toast, BorderLayout.SOUTH);
        toastTimer = new Timer(2600, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toast.setVisible(false);
            }
        });
        toastTimer.setRepeats(false);
        setContentPane(root);

        nameComponents();
        syncOptionControls();
        registerListeners();
        refreshProducts();
        refreshCart();

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        UiUtil.fitToScreen(this, 1340, 840);
        setMinimumSize(new Dimension(1100, 640));
        setLocationRelativeTo(null);
    }

    // =====================================================================
    //  Layout
    // =====================================================================

    private JMenuBar buildMenuBar() {
        JMenu cartMenu = new JMenu("Cart");
        cartMenu.setMnemonic(KeyEvent.VK_C);
        checkoutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, InputEvent.CTRL_DOWN_MASK));
        closeItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_DOWN_MASK));
        cartMenu.add(checkoutItem);
        cartMenu.add(emptyItem);
        cartMenu.addSeparator();
        cartMenu.add(closeItem);
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        helpMenu.add(couponsItem);
        helpMenu.add(aboutItem);
        JMenuBar bar = new JMenuBar();
        bar.add(cartMenu);
        bar.add(helpMenu);
        return bar;
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout(20, 0)) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, UiUtil.SHOP_COLOR, getWidth(), 0, new Color(160, 52, 10)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        bar.setBorder(new EmptyBorder(12, 20, 12, 20));

        JLabel logo = new JLabel("<html><b style='font-size:17px'>HD</b> <i style='font-size:17px'>Cart</i></html>",
                Art.cart(30, Color.WHITE), SwingConstants.LEFT);
        logo.setForeground(Color.WHITE);
        logo.setIconTextGap(10);
        bar.add(logo, BorderLayout.WEST);

        JPanel search = new JPanel(new BorderLayout(6, 0));
        search.setOpaque(false);
        searchField.setPreferredSize(new Dimension(420, 36));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230)), new EmptyBorder(4, 10, 4, 10)));
        search.add(searchField, BorderLayout.CENTER);
        search.add(searchButton, BorderLayout.EAST);
        JPanel searchHolder = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        searchHolder.setOpaque(false);
        searchHolder.add(search);
        bar.add(searchHolder, BorderLayout.CENTER);

        cartBadge.setIcon(Art.cart(26, Color.WHITE));
        cartBadge.setForeground(Color.WHITE);
        cartBadge.setIconTextGap(8);
        bar.add(cartBadge, BorderLayout.EAST);
        return bar;
    }

    private JPanel buildFilterBar() {
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        chips.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        for (String category : Store.CATEGORIES) {
            JToggleButton chip = new Chip(category);
            chip.setName("chip-" + category);
            group.add(chip);
            categoryChips.add(chip);
            chips.add(chip);
        }
        categoryChips.get(0).setSelected(true);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        resultsLabel.setForeground(new Color(100, 108, 120));
        right.add(resultsLabel);
        right.add(Box.createHorizontalStrut(10));
        right.add(new JLabel("Sort by"));
        right.add(sortCombo);

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 230, 236)), new EmptyBorder(10, 14, 10, 14)));
        bar.add(chips, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    private JScrollPane buildGrid() {
        gridPanel.setOpaque(false);
        JPanel holder = new JPanel(new BorderLayout());
        holder.setBackground(UiUtil.PAGE_BG);
        holder.setBorder(new EmptyBorder(16, 16, 16, 12));
        holder.add(gridPanel, BorderLayout.NORTH); // NORTH keeps cards at their natural height
        JScrollPane scroll = new JScrollPane(holder);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(24);
        return scroll;
    }

    private JPanel buildCartSidebar() {
        cartTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        cartTitle.setBorder(new EmptyBorder(14, 16, 10, 16));

        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));
        itemsPanel.setBackground(Color.WHITE);
        JPanel itemsHolder = new JPanel(new BorderLayout());
        itemsHolder.setBackground(Color.WHITE);
        itemsHolder.add(itemsPanel, BorderLayout.NORTH);
        JScrollPane itemsScroll = new JScrollPane(itemsHolder);
        itemsScroll.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(232, 235, 240)));
        itemsScroll.getVerticalScrollBar().setUnitIncrement(20);

        deliveryBar.setForeground(UiUtil.OK_GREEN);
        deliveryBar.setPreferredSize(new Dimension(300, 8));
        deliveryBar.setBorderPainted(false);
        deliveryLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        JPanel couponRow = new JPanel(new BorderLayout(6, 0));
        couponRow.setOpaque(false);
        couponField.setPreferredSize(new Dimension(150, 32));
        couponRow.add(couponField, BorderLayout.CENTER);
        couponRow.add(applyCouponButton, BorderLayout.EAST);
        couponLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        giftWrapBox.setOpaque(false);
        JPanel payRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        payRow.setOpaque(false);
        payRow.add(new JLabel("Pay by:"));
        ButtonGroup payGroup = new ButtonGroup();
        for (JRadioButton radio : new JRadioButton[] {upiRadio, cardRadio, codRadio}) {
            radio.setOpaque(false);
            payGroup.add(radio);
            payRow.add(radio);
        }

        JPanel summary = new JPanel(new GridLayout(0, 2, 6, 3));
        summary.setOpaque(false);
        addSummaryRow(summary, "Subtotal", subtotalValue);
        addSummaryRow(summary, "Tax", taxValue);
        addSummaryRow(summary, "Coupon discount", discountValue);
        addSummaryRow(summary, "Delivery", deliveryValue);
        addSummaryRow(summary, "Gift wrap / COD", otherValue);
        JLabel totalLabel = new JLabel("Total");
        Font big = new Font("Segoe UI", Font.BOLD, 18);
        totalLabel.setFont(big);
        totalValue.setFont(big);
        totalValue.setForeground(new Color(33, 37, 41));
        summary.add(totalLabel);
        summary.add(totalValue);

        checkoutButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        checkoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        checkoutButton.setPreferredSize(new Dimension(320, 44));

        JPanel bottom = new JPanel();
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(new EmptyBorder(10, 16, 14, 16));
        JComponent[] parts = {deliveryLabel, deliveryBar, gap(10), couponRow, couponLabel, gap(4), giftWrapBox, payRow,
            gap(8), separator(), gap(8), summary, gap(12), checkoutButton};
        for (JComponent part : parts) {
            part.setAlignmentX(LEFT_ALIGNMENT);
            if (part != checkoutButton && part != deliveryBar) {
                part.setMaximumSize(new Dimension(Integer.MAX_VALUE, part.getPreferredSize().height));
            }
            bottom.add(part);
        }
        deliveryBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));

        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(Color.WHITE);
        sidebar.setPreferredSize(new Dimension(400, 10));
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(220, 224, 230)));
        sidebar.add(cartTitle, BorderLayout.NORTH);
        sidebar.add(itemsScroll, BorderLayout.CENTER);
        sidebar.add(bottom, BorderLayout.SOUTH);
        return sidebar;
    }

    private static JComponent gap(int height) {
        return (JComponent) Box.createVerticalStrut(height);
    }

    private static JComponent separator() {
        JPanel line = new JPanel();
        line.setBackground(new Color(226, 230, 236));
        line.setPreferredSize(new Dimension(10, 1));
        return line;
    }

    private static void addSummaryRow(JPanel summary, String label, JLabel value) {
        JLabel l = new JLabel(label);
        l.setForeground(new Color(90, 98, 110));
        summary.add(l);
        summary.add(value);
    }

    private static JLabel valueLabel() {
        JLabel label = new JLabel("Rs. 0.00", SwingConstants.RIGHT);
        label.setFont(UiUtil.BOLD_FONT);
        return label;
    }

    private void nameComponents() {
        JComponent[] components = {searchField, searchButton, cartBadge, sortCombo, couponField, applyCouponButton,
            couponLabel, giftWrapBox, upiRadio, cardRadio, codRadio, totalValue, checkoutButton, deliveryLabel, itemsPanel};
        String[] names = {"search", "searchButton", "cartBadge", "sort", "coupon", "applyCoupon", "couponLabel",
            "giftWrap", "upi", "card", "cod", "total", "checkout", "deliveryLabel", "cartItems"};
        for (int i = 0; i < components.length; i++) {
            components[i].setName(names[i]);
        }
    }

    // =====================================================================
    //  Event handling
    // =====================================================================

    private void registerListeners() {
        AbstractButton[] actionSources = {searchButton, applyCouponButton, checkoutButton,
            checkoutItem, emptyItem, closeItem, couponsItem, aboutItem};
        for (AbstractButton source : actionSources) {
            source.addActionListener(this);
        }
        searchField.addActionListener(this);   // Enter = search
        couponField.addActionListener(this);   // Enter = apply coupon

        for (JToggleButton chip : categoryChips) {
            chip.addItemListener(this);
        }
        sortCombo.addItemListener(this);
        giftWrapBox.addItemListener(this);
        upiRadio.addItemListener(this);
        cardRadio.addItemListener(this);
        codRadio.addItemListener(this);

        // KeyAdapter: filter the products while the user types
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                refreshProducts();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        String command = e.getActionCommand();
        if (ProductCard.ADD.equals(command)) {
            addToCart((JComponent) source);
        } else if (ProductCard.DETAILS.equals(command)) {
            showDetails((Product) ((JComponent) source).getClientProperty("product"));
        } else if (CartRow.PLUS.equals(command) || CartRow.MINUS.equals(command)) {
            stepQuantity((JComponent) source, CartRow.PLUS.equals(command) ? 1 : -1);
        } else if (CartRow.REMOVE.equals(command)) {
            removeItem((Integer) ((JComponent) source).getClientProperty("index"));
        } else if (source == searchButton || source == searchField) {
            refreshProducts();
        } else if (source == applyCouponButton || source == couponField) {
            applyCoupon();
        } else if (source == checkoutButton || source == checkoutItem) {
            checkout();
        } else if (source == emptyItem) {
            emptyCart();
        } else if (source == couponsItem) {
            showCoupons();
        } else if (source == aboutItem) {
            UiUtil.showInfo(this, "About", "HD Cart - Online Shopping Cart\nPart of HD Suite - Java Swing mini project"
                    + "\n\nProducts, prices, ratings and tax rates are demo data for learning purposes.");
        } else if (source == closeItem) {
            dispose();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();
        if (source == giftWrapBox) {
            cart.setGiftWrap(giftWrapBox.isSelected());
            refreshSummary();
            return;
        }
        if (e.getStateChange() != ItemEvent.SELECTED) {
            return;
        }
        if (source == codRadio) {
            cart.setPaymentMode(ShoppingCart.PAY_COD);
            refreshSummary();
        } else if (source == cardRadio) {
            cart.setPaymentMode(ShoppingCart.PAY_CARD);
            refreshSummary();
        } else if (source == upiRadio) {
            cart.setPaymentMode(ShoppingCart.PAY_UPI);
            refreshSummary();
        } else {
            refreshProducts(); // a category chip or the sort order changed
        }
    }

    // =====================================================================
    //  Actions
    // =====================================================================

    private void addToCart(JComponent button) {
        Product product = (Product) button.getClientProperty("product");
        JComboBox<?> quantityCombo = (JComboBox<?>) button.getClientProperty("quantity");
        try {
            int quantity = (Integer) quantityCombo.getSelectedItem();
            cart.add(product, quantity);
            refreshCart();
            showToast("Added " + quantity + " x " + product.getName() + " to your cart", UiUtil.OK_GREEN);
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void stepQuantity(JComponent button, int change) {
        int index = (Integer) button.getClientProperty("index");
        CartItem item = cart.getItems().get(index);
        try {
            cart.updateQuantity(index, item.getQuantity() + change);
            refreshCart();
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void removeItem(int index) {
        try {
            CartItem removed = cart.remove(index);
            refreshCart();
            showToast("Removed " + removed.getProduct().getName() + " from your cart", new Color(90, 98, 110));
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void applyCoupon() {
        try {
            cart.applyCoupon(couponField.getText());
            refreshCart();
            showToast("Coupon " + cart.getCoupon().getCode() + " applied - you save " + Money.format(cart.getDiscount()),
                    UiUtil.OK_GREEN);
        } catch (ValidationException ex) {
            UiUtil.showError(this, ex.getMessage());
        }
    }

    private void checkout() {
        if (cart.isEmpty()) {
            UiUtil.showError(this, "Your cart is empty. Add some products first.");
            return;
        }
        CheckoutDialog dialog = new CheckoutDialog(this, store, cart);
        dialog.setVisible(true); // modal: waits here until the dialog closes
        if (dialog.isOrderPlaced()) {
            syncOptionControls();
            refreshProducts();
            refreshCart();
            showToast("Order " + store.getLastOrderId() + " placed successfully. Thank you!", UiUtil.OK_GREEN);
        }
    }

    private void emptyCart() {
        if (cart.isEmpty()) {
            showToast("Your cart is already empty", new Color(90, 98, 110));
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Remove all items from your cart?", "Empty Cart",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            cart.clear();
            syncOptionControls();
            refreshCart();
        }
    }

    private void showDetails(Product product) {
        JPanel panel = new JPanel(new BorderLayout(16, 0));
        panel.add(new JLabel(Art.product(product.getId(), 220, 220)), BorderLayout.WEST);
        JPanel right = new JPanel(new BorderLayout(0, 8));
        JLabel stars = new JLabel(String.format(Locale.ENGLISH, "%.1f out of 5  (%,d ratings)",
                product.getRating(), product.getReviews()), Art.stars(product.getRating(), 16), JLabel.LEFT);
        right.add(stars, BorderLayout.NORTH);
        JTextArea details = new JTextArea(product.getDetails() + "\nMRP        : " + Money.format(product.getMrp())
                + "  (you save " + product.getDiscountPercent() + "%)");
        details.setEditable(false);
        details.setOpaque(false);
        details.setFont(UiUtil.monoFont(13));
        right.add(details, BorderLayout.CENTER);
        panel.add(right, BorderLayout.CENTER);
        JOptionPane.showMessageDialog(this, panel, product.getName(), JOptionPane.PLAIN_MESSAGE);
    }

    private void showCoupons() {
        StringBuilder sb = new StringBuilder("Available coupons:\n\n");
        for (Coupon coupon : Coupon.all()) {
            sb.append(String.format(Locale.ENGLISH, "  %-8s  %s\n", coupon.getCode(), coupon.getDescription()));
        }
        sb.append("\nDelivery is free for orders of Rs 999 and above (otherwise Rs 49).");
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(UiUtil.monoFont(13));
        JOptionPane.showMessageDialog(this, area, "Coupons", JOptionPane.INFORMATION_MESSAGE);
    }

    // =====================================================================
    //  Refreshing the screen
    // =====================================================================

    private void refreshProducts() {
        String category = "All";
        for (JToggleButton chip : categoryChips) {
            if (chip.isSelected()) {
                category = chip.getText();
            }
        }
        List<Product> products = store.search(category, searchField.getText());
        sort(products);

        gridPanel.removeAll();
        for (Product product : products) {
            gridPanel.add(new ProductCard(product, this));
        }
        if (products.isEmpty()) {
            JLabel none = new JLabel("<html><center><b style='font-size:15px'>No products found</b><br><br>"
                    + "Try another word or category.</center></html>", SwingConstants.CENTER);
            none.setForeground(new Color(110, 116, 128));
            none.setPreferredSize(new Dimension(250, 200));
            gridPanel.add(none);
        }
        resultsLabel.setText(products.size() + (products.size() == 1 ? " product" : " products"));
        gridPanel.revalidate();
        gridPanel.repaint();
    }

    private void sort(List<Product> products) {
        int option = sortCombo.getSelectedIndex();
        Comparator<Product> order = null;
        if (option == 1) {
            order = new Comparator<Product>() {
                public int compare(Product a, Product b) {
                    return Double.compare(a.getPrice(), b.getPrice());
                }
            };
        } else if (option == 2) {
            order = new Comparator<Product>() {
                public int compare(Product a, Product b) {
                    return Double.compare(b.getPrice(), a.getPrice());
                }
            };
        } else if (option == 3) {
            order = new Comparator<Product>() {
                public int compare(Product a, Product b) {
                    return Double.compare(b.getRating(), a.getRating());
                }
            };
        } else if (option == 4) {
            order = new Comparator<Product>() {
                public int compare(Product a, Product b) {
                    return b.getDiscountPercent() - a.getDiscountPercent();
                }
            };
        }
        if (order != null) {
            Collections.sort(products, order);
        }
    }

    private void refreshCart() {
        itemsPanel.removeAll();
        List<CartItem> items = cart.getItems();
        for (int i = 0; i < items.size(); i++) {
            itemsPanel.add(new CartRow(items.get(i), i, this));
        }
        if (items.isEmpty()) {
            JLabel empty = new JLabel("<html><center><b style='font-size:14px'>Your cart is empty</b><br>"
                    + "Add items from the shop to get started.</center></html>",
                    Art.cart(64, new Color(205, 210, 218)), SwingConstants.CENTER);
            empty.setHorizontalTextPosition(SwingConstants.CENTER);
            empty.setVerticalTextPosition(SwingConstants.BOTTOM);
            empty.setForeground(new Color(120, 126, 138));
            empty.setBorder(new EmptyBorder(40, 0, 20, 0));
            empty.setAlignmentX(LEFT_ALIGNMENT);
            empty.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
            JPanel holder = new JPanel(new BorderLayout());
            holder.setOpaque(false);
            holder.add(empty);
            holder.setAlignmentX(LEFT_ALIGNMENT);
            itemsPanel.add(holder);
        }
        itemsPanel.revalidate();
        itemsPanel.repaint();

        int count = cart.getTotalQuantity();
        cartTitle.setText("Your Cart  (" + count + (count == 1 ? " item)" : " items)"));
        cartBadge.setText("<html><b style='font-size:14px'>Cart</b>&nbsp;<span style='background:#ffc400;color:#212529'>"
                + "&nbsp;<b>" + count + "</b>&nbsp;</span></html>");
        checkoutButton.setEnabled(!cart.isEmpty());
        refreshSummary();
    }

    private void refreshSummary() {
        subtotalValue.setText(Money.format(cart.getSubtotal()));
        taxValue.setText(Money.format(cart.getTax()));
        discountValue.setText(cart.getDiscount() > 0 ? "- " + Money.format(cart.getDiscount()) : Money.format(0));
        discountValue.setForeground(cart.getDiscount() > 0 ? UiUtil.OK_GREEN : new Color(33, 37, 41));
        deliveryValue.setText(cart.isEmpty() ? Money.format(0)
                : cart.getDeliveryCharge() == 0 ? "FREE" : Money.format(cart.getDeliveryCharge()));
        deliveryValue.setForeground(!cart.isEmpty() && cart.getDeliveryCharge() == 0 ? UiUtil.OK_GREEN : new Color(33, 37, 41));
        otherValue.setText(Money.format(cart.getOtherCharges()));
        totalValue.setText(Money.format(cart.getGrandTotal()));
        checkoutButton.setText(cart.isEmpty() ? "Cart is empty" : "Proceed to Checkout");

        double subtotal = cart.getSubtotal();
        deliveryBar.setValue((int) Math.min(subtotal, ShoppingCart.FREE_DELIVERY_ABOVE));
        if (cart.isEmpty()) {
            deliveryLabel.setText("Free delivery on orders of Rs. 999 and above");
            deliveryLabel.setForeground(new Color(110, 116, 128));
        } else if (subtotal >= ShoppingCart.FREE_DELIVERY_ABOVE) {
            deliveryLabel.setText("Yay! Your order gets FREE delivery");
            deliveryLabel.setForeground(UiUtil.OK_GREEN);
        } else {
            deliveryLabel.setText("Add " + Money.format(ShoppingCart.FREE_DELIVERY_ABOVE - subtotal)
                    + " more for FREE delivery");
            deliveryLabel.setForeground(UiUtil.WARN_ORANGE);
        }

        Coupon coupon = cart.getCoupon();
        if (coupon == null) {
            couponLabel.setText("Try SAVE10, FLAT200 or FEST20");
            couponLabel.setForeground(new Color(120, 126, 138));
        } else if (cart.getDiscount() > 0) {
            couponLabel.setText(coupon.getCode() + " applied: " + coupon.getDescription());
            couponLabel.setForeground(UiUtil.OK_GREEN);
        } else {
            couponLabel.setText(coupon.getCode() + " needs an order of " + Money.format(coupon.getMinimumSubtotal()));
            couponLabel.setForeground(UiUtil.WARN_ORANGE);
        }
    }

    /** Makes the gift-wrap checkbox, payment buttons and coupon box match the cart (e.g. after an order). */
    private void syncOptionControls() {
        giftWrapBox.setSelected(cart.isGiftWrap());
        if (ShoppingCart.PAY_COD.equals(cart.getPaymentMode())) {
            codRadio.setSelected(true);
        } else if (ShoppingCart.PAY_CARD.equals(cart.getPaymentMode())) {
            cardRadio.setSelected(true);
        } else {
            upiRadio.setSelected(true);
        }
        couponField.setText(cart.getCoupon() == null ? "" : cart.getCoupon().getCode());
    }

    private void showToast(String message, Color color) {
        toast.setText(message);
        toast.setBackground(color);
        toast.setVisible(true);
        toastTimer.restart();
    }

    // =====================================================================
    //  Small custom components
    // =====================================================================

    /** Text field that shows a grey hint while it is empty. */
    private static final class HintTextField extends JTextField {
        private static final long serialVersionUID = 1L;
        private final String hint;

        HintTextField(String hint) {
            this.hint = hint;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty()) {
                Graphics2D g2 = Art.smooth(g);
                g2.setColor(new Color(150, 156, 166));
                g2.setFont(getFont());
                java.awt.Insets in = getInsets();
                g2.drawString(hint, in.left + 2, (getHeight() + g2.getFontMetrics().getAscent()) / 2 - 2);
                g2.dispose();
            }
        }
    }

    /** Pill-shaped category filter (a JToggleButton): orange when selected. */
    private static final class Chip extends JToggleButton {
        private static final long serialVersionUID = 1L;

        Chip(String text) {
            super(text);
            setFont(UiUtil.BOLD_FONT);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setBorder(new EmptyBorder(6, 16, 6, 16));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = Art.smooth(g);
            RoundRectangle2D shape = new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1,
                    getHeight(), getHeight());
            if (isSelected()) {
                g2.setColor(UiUtil.SHOP_COLOR);
                g2.fill(shape);
                setForeground(Color.WHITE);
            } else {
                g2.setColor(getModel().isRollover() ? new Color(255, 240, 230) : new Color(244, 246, 249));
                g2.fill(shape);
                g2.setColor(new Color(214, 218, 226));
                g2.draw(shape);
                setForeground(new Color(55, 65, 81));
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
