import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/** One line in the cart sidebar: thumbnail, name, - qty + stepper, line total and Remove. */
public class CartRow extends JPanel {

    private static final long serialVersionUID = 1L;

    public static final String PLUS = "PLUS";
    public static final String MINUS = "MINUS";
    public static final String REMOVE = "REMOVE";

    public CartRow(CartItem item, int index, ActionListener listener) {
        super(new BorderLayout(10, 0));
        Product product = item.getProduct();
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(232, 235, 240)), new EmptyBorder(8, 6, 8, 6)));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 86));
        setAlignmentX(LEFT_ALIGNMENT);

        add(new JLabel(Art.product(product.getId(), 58, 58)), BorderLayout.WEST);

        JPanel middle = new JPanel();
        middle.setOpaque(false);
        middle.setLayout(new BoxLayout(middle, BoxLayout.Y_AXIS));
        JLabel name = new JLabel(product.getName());
        name.setFont(UiUtil.BOLD_FONT);
        JLabel each = new JLabel(Money.format(product.getPrice()) + " each");
        each.setForeground(new Color(110, 116, 128));
        JPanel stepper = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 2));
        stepper.setOpaque(false);
        FlatButton minus = stepButton("-", MINUS, index, listener);
        minus.setEnabled(item.getQuantity() > 1);
        JLabel quantity = new JLabel(String.valueOf(item.getQuantity()), JLabel.CENTER);
        quantity.setFont(UiUtil.BOLD_FONT);
        quantity.setPreferredSize(new Dimension(26, 26));
        quantity.setName("cartQty-" + product.getId());
        FlatButton plus = stepButton("+", PLUS, index, listener);
        minus.setName("minus-" + product.getId());
        plus.setName("plus-" + product.getId());
        stepper.add(minus);
        stepper.add(quantity);
        stepper.add(plus);
        for (javax.swing.JComponent c : new javax.swing.JComponent[] {name, each, stepper}) {
            c.setAlignmentX(LEFT_ALIGNMENT);
            middle.add(c);
        }
        add(middle, BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        JLabel total = new JLabel(Money.format(item.getSubtotal()), JLabel.RIGHT);
        total.setFont(new Font("Segoe UI", Font.BOLD, 14));
        FlatButton remove = new FlatButton("Remove", Color.WHITE, UiUtil.ERROR_RED);
        remove.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        remove.setBorder(new EmptyBorder(2, 8, 2, 8));
        remove.setPreferredSize(new Dimension(72, 26));
        remove.setActionCommand(REMOVE);
        remove.setName("remove-" + product.getId());
        remove.putClientProperty("index", index);
        remove.addActionListener(listener);
        right.add(total, BorderLayout.NORTH);
        right.add(remove, BorderLayout.SOUTH);
        add(right, BorderLayout.EAST);
    }

    private static FlatButton stepButton(String text, String command, int index, ActionListener listener) {
        FlatButton b = new FlatButton(text, new Color(240, 242, 246), new Color(33, 37, 41));
        b.setFont(new Font("Segoe UI", Font.BOLD, 15));
        b.setBorder(new EmptyBorder(0, 0, 2, 0));
        b.setPreferredSize(new Dimension(28, 26));
        b.setActionCommand(command);
        b.putClientProperty("index", index);
        b.addActionListener(listener);
        return b;
    }
}
