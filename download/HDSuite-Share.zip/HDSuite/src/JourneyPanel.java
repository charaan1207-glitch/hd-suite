import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.Icon;
import javax.swing.JPanel;

/**
 * Draws the selected journey like a booking site does:
 * departure time and station on the left, arrival on the right,
 * and the train running along the line between them.
 */
public class JourneyPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    private final Icon trainIcon = Art.train(54, 40, UiUtil.RAIL_COLOR);
    private Train train;
    private String className = "";
    private String dateText = "";

    public JourneyPanel() {
        setOpaque(false);
        setPreferredSize(new Dimension(400, 96));
    }

    public void setJourney(Train train, String className, String dateText) {
        this.train = train;
        this.className = className;
        this.dateText = dateText;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = Art.smooth(g);
        int w = getWidth();
        int h = getHeight();
        g2.setColor(new Color(236, 244, 253));
        g2.fill(new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 14, 14));
        g2.setColor(new Color(200, 220, 245));
        g2.draw(new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 14, 14));

        if (train == null) {
            g2.setFont(UiUtil.BOLD_FONT);
            g2.setColor(new Color(120, 130, 145));
            String text = "No direct train on this route - choose other stations";
            g2.drawString(text, (w - g2.getFontMetrics().stringWidth(text)) / 2, h / 2 + 5);
            g2.dispose();
            return;
        }

        int pad = 16;
        String[] dep = splitTime(train.getDeparture());
        String[] arr = splitTime(train.getArrival());

        g2.setFont(new Font("Segoe UI", Font.BOLD, 22));
        g2.setColor(new Color(20, 40, 70));
        g2.drawString(dep[0], pad, 36);
        FontMetrics big = g2.getFontMetrics();
        int arrWidth = big.stringWidth(arr[0]);
        g2.drawString(arr[0], w - pad - arrWidth, 36);

        g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        FontMetrics small = g2.getFontMetrics();
        g2.setColor(new Color(70, 85, 105));
        g2.drawString(train.getSource(), pad, 56);
        g2.drawString(train.getDestination(), w - pad - small.stringWidth(train.getDestination()), 56);
        if (!arr[1].isEmpty()) {
            g2.setColor(UiUtil.WARN_ORANGE);
            String days = arr[1] + (arr[1].equals("+1") ? " day" : " days");
            g2.drawString(days, w - pad - small.stringWidth(days), 72);
        }

        // the line and the train
        int x1 = pad + big.stringWidth(dep[0]) + 16;
        int x2 = w - pad - arrWidth - 16;
        int y = 28;
        g2.setColor(new Color(150, 180, 220));
        g2.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1, new float[] {6, 5}, 0));
        g2.draw(new Line2D.Double(x1, y, x2, y));
        g2.setStroke(new BasicStroke(1));
        g2.setColor(UiUtil.RAIL_COLOR);
        g2.fill(new Ellipse2D.Double(x1 - 5, y - 5, 10, 10));
        g2.fill(new Ellipse2D.Double(x2 - 5, y - 5, 10, 10));
        int mid = (x1 + x2) / 2;
        trainIcon.paintIcon(this, g2, mid - trainIcon.getIconWidth() / 2, y - 31);

        g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
        g2.setColor(new Color(20, 40, 70));
        String name = train.getNumber() + "  " + train.getName();
        g2.drawString(name, mid - g2.getFontMetrics().stringWidth(name) / 2, 56);
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        g2.setColor(new Color(90, 105, 125));
        String info = train.getDistanceKm() + " km  |  " + className + (dateText.isEmpty() ? "" : "  |  " + dateText);
        g2.drawString(info, mid - g2.getFontMetrics().stringWidth(info) / 2, 74);
        g2.dispose();
    }

    /** "06:30 (+2)" becomes {"06:30", "+2"}. */
    private static String[] splitTime(String time) {
        int space = time.indexOf(' ');
        if (space < 0) {
            return new String[] {time, ""};
        }
        return new String[] {time.substring(0, space), time.substring(space + 1).replace("(", "").replace(")", "")};
    }
}
