/** The person travelling on a ticket. */
public class Passenger {

    public static final int SENIOR_CITIZEN_AGE = 60;
    public static final int CHILD_MAX_AGE = 11;

    private final String name;
    private final int age;
    private final String gender;
    private final String mobile;

    public Passenger(String name, int age, String gender, String mobile) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getMobile() {
        return mobile;
    }

    public boolean isSeniorCitizen() {
        return age >= SENIOR_CITIZEN_AGE;
    }

    public boolean isChild() {
        return age <= CHILD_MAX_AGE;
    }
}
