import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 * A modern rounded button. It extends JButton (inheritance) and overrides
 * paintComponent() to draw its own background, which darkens on hover.
 */
public class FlatButton extends JButton {

    private static final long serialVersionUID = 1L;

    private final Color color;
    private final Color textColor;
    private boolean hover;

    public FlatButton(String text, Color color, Color textColor) {
        super(text);
        this.color = color;
        this.textColor = textColor;
        setForeground(textColor);
        setFont(UiUtil.BOLD_FONT);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setOpaque(false);
        setBorder(new EmptyBorder(8, 16, 8, 16));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hover = false;
                repaint();
            }
        });
    }

    /** Solid coloured button with white text. */
    public FlatButton(String text, Color color) {
        this(text, color, Color.WHITE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = Art.smooth(g);
        Color fill;
        if (!isEnabled()) {
            fill = new Color(205, 208, 214);
        } else if (getModel().isPressed()) {
            fill = color.darker();
        } else if (hover) {
            fill = mix(color, Color.BLACK, 0.12);
        } else {
            fill = color;
        }
        g2.setColor(fill);
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 10, 10));
        if (color.equals(Color.WHITE) || color.getRed() > 230 && color.getGreen() > 230 && color.getBlue() > 230) {
            g2.setColor(new Color(200, 205, 214));
            g2.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 10, 10));
        }
        g2.dispose();
        setForeground(isEnabled() ? textColor : new Color(110, 115, 125));
        super.paintComponent(g);
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        return isPreferredSizeSet() ? d : new Dimension(d.width, Math.max(d.height, 34));
    }

    private static Color mix(Color a, Color b, double amount) {
        return new Color((int) (a.getRed() * (1 - amount) + b.getRed() * amount),
                (int) (a.getGreen() * (1 - amount) + b.getGreen() * amount),
                (int) (a.getBlue() * (1 - amount) + b.getBlue() * amount));
    }
}
