/**
 * A discount coupon. Two kinds exist - a percentage discount and a flat
 * discount - and each overrides discountOn() in its own way.
 */
public abstract class Coupon {

    private static final Coupon[] ALL = {
        new PercentCoupon("SAVE10", "10% off (max Rs 500)", 0, 10, 500),
        new FlatCoupon("FLAT200", "Rs 200 off on orders of Rs 1,500 or more", 1500, 200),
        new PercentCoupon("FEST20", "20% off on orders of Rs 3,000 or more (max Rs 1,000)", 3000, 20, 1000)
    };

    private final String code;
    private final String description;
    private final double minimumSubtotal;

    protected Coupon(String code, String description, double minimumSubtotal) {
        this.code = code;
        this.description = description;
        this.minimumSubtotal = minimumSubtotal;
    }

    /** The discount this coupon gives on the given subtotal (assumes it is eligible). */
    public abstract double discountOn(double subtotal);

    public boolean isEligible(double subtotal) {
        return subtotal >= minimumSubtotal;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public double getMinimumSubtotal() {
        return minimumSubtotal;
    }

    public static Coupon[] all() {
        return ALL.clone();
    }

    public static Coupon find(String rawCode) throws ValidationException {
        String code = rawCode == null ? "" : rawCode.trim().toUpperCase();
        if (code.isEmpty()) {
            throw new ValidationException("Please enter a coupon code.");
        }
        for (Coupon coupon : ALL) {
            if (coupon.code.equals(code)) {
                return coupon;
            }
        }
        throw new ValidationException("Coupon \"" + code + "\" is not valid. Try SAVE10, FLAT200 or FEST20.");
    }

    /** X% off, capped at a maximum amount. */
    static final class PercentCoupon extends Coupon {
        private final double percent;
        private final double maxDiscount;

        PercentCoupon(String code, String description, double minimumSubtotal, double percent, double maxDiscount) {
            super(code, description, minimumSubtotal);
            this.percent = percent;
            this.maxDiscount = maxDiscount;
        }

        @Override
        public double discountOn(double subtotal) {
            return Money.round(Math.min(subtotal * percent / 100.0, maxDiscount));
        }
    }

    /** A fixed amount off. */
    static final class FlatCoupon extends Coupon {
        private final double amount;

        FlatCoupon(String code, String description, double minimumSubtotal, double amount) {
            super(code, description, minimumSubtotal);
            this.amount = amount;
        }

        @Override
        public double discountOn(double subtotal) {
            return Math.min(amount, subtotal);
        }
    }
}
