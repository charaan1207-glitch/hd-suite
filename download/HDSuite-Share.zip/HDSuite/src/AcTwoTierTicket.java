import java.time.LocalDate;

/**
 * AC 2 Tier (2A): has no middle berth, so it overrides the berth layout,
 * and it serves a costlier meal.
 */
public class AcTwoTierTicket extends Ticket {

    public static final int SEATS = 4;

    public AcTwoTierTicket(String pnr, Passenger passenger, Train train, LocalDate journeyDate,
                           String berthPreference, boolean meals, boolean insurance) {
        super(pnr, passenger, train, journeyDate, berthPreference, meals, insurance);
    }

    @Override
    public String getClassCode() {
        return "2A";
    }

    @Override
    public String getClassName() {
        return "AC 2 Tier";
    }

    @Override
    public int getTotalSeats() {
        return SEATS;
    }

    @Override
    protected double getRatePerKm() {
        return 2.20;
    }

    @Override
    protected double getReservationCharge() {
        return 50.0;
    }

    @Override
    protected double getGstPercent() {
        return 5.0;
    }

    @Override
    protected String getCoachCode() {
        return "A1";
    }

    @Override
    public double getCancellationCharge() {
        return 200.0;
    }

    @Override
    protected double getMealPrice() {
        return 200.0;
    }

    /** 2A bay: Lower, Upper x2, then Side Lower, Side Upper (no middle berth). */
    @Override
    public String getBerthType(int seat) {
        String[] bay = {"LB", "UB", "LB", "UB", "SL", "SU"};
        return bay[(seat - 1) % bay.length];
    }
}
